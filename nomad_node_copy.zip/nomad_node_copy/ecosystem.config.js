module.exports = {
  apps : [{
    name   : "nomad_node",
    script : "npm run start",
    restart_delay: 1000,
    instances : -1,
    cron_restart: '0 */1 * * *',
  }]
}
