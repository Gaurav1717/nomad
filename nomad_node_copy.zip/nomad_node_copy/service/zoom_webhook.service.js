import Session from '../models/session.model.js';
import DemoSession from '../models/bookSession.model.js';
import Utility from '../library/utility.js';
var service = {};

service.start_stop = async (req, res) => {
  try {
    const zoomId = req.body.payload.object.id;

    var session = await Utility.getOneDb(Session, {zoomId: zoomId});
    var demo_session = null;
    if(!session){
      demo_session = await Utility.getOneDb(DemoSession, {zoomId: zoomId});
    }

    if(req.body.event == "meeting.started"){
      const updateData = {
        meetingStartTime: new Date()
      }

      if(session){
        Utility.updateDb(Session, {zoomId: zoomId}, updateData);
      }
      else if(demo_session){
        Utility.updateDb(DemoSession, {zoomId: zoomId}, updateData);
      }
    }
    else if(req.body.event == "meeting.ended"){
      const updateData = {
        meetingEndTime: new Date(),
        status: "completed"
      }

      if(session){
        Utility.updateDb(Session, {zoomId: zoomId}, updateData);
      }
      else if(demo_session){
        Utility.updateDb(DemoSession, {zoomId: zoomId}, updateData);
      }
    }

    return res.success();
  } catch (err) {
    console.log(err);
  }
}

service.participant_join = async (req, res) => {
  try {

    if(req.body.event == "meeting.participant_joined"){
      const zoomId = req.body.payload.object.id;
      const participant = req.body.payload.object.participant;

      var session = await Utility.getOneDb(Session, {zoomId: zoomId});
      var demo_session = null;
      if(!session){
        demo_session = await Utility.getOneDb(DemoSession, {zoomId: zoomId});
      }

      if(participant.email){
        const updateData = {
          consultantJoinTime: new Date()
        }
        
        if(session){
          Utility.updateDb(Session, {zoomId: zoomId}, updateData);
        }
        else if(demo_session){
          Utility.updateDb(DemoSession, {zoomId: zoomId}, updateData);
        }
      }
      else{
        const updateData = {
          customerJoinTime: new Date()
        }

        if(session){
          Utility.updateDb(Session, {zoomId: zoomId}, updateData);
        }
        else if(demo_session){
          Utility.updateDb(DemoSession, {zoomId: zoomId}, updateData);
        }
      } 
    }

    return res.success();
  } catch (err) {
    console.log(err);
  }
}

export default service;