import Country from '../models/country.model.js';
import State from '../models/state.model.js';
import City from '../models/city.model.js';
import Utility from '../library/utility.js';
var service = {};

service.countries = async (req, res) => {
  try {
    const countries = await Utility.findDb(Country,{status: "active"});
    return res.send({data: countries});
  } catch (err) {
    console.log(err);
  }
}

service.states = async (req, res) => {
  try {
    const states = await Utility.findDb(State, {status: "active", countryId: req.query.countryId});
    
    return res.send({data: states});
  } catch (err) {
    console.log(err);
  }
}

service.cities = async (req, res) => {
  try {
    const cities = await Utility.findDb(City, {status: "active", countryId: req.query.countryId},{name: 0});
    return res.send({data: cities});
  } catch (err) {
    console.log(err);
  }
}

export default service;