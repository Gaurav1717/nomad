import User from '../../models/user.model.js';
import Utility from '../../library/utility.js';
import Session from '../../models/session.model.js';
const moment = require('moment');
const bcrypt = require('bcrypt');

var service = {};

service.consultantReport = async (req, res) => {
    const page = req.query.page?parseInt(req.query.page):1;
    let pagination = {
        page: page ? (page !=0 ? page-1:0) : 0,
        limit: req.query.limit ? parseInt(req.query.limit) : 10,
    };

    if(req.query.orderBy){
        pagination["sort"] = {};
        if (req.query.orderDirection == 'asc') {
            pagination["sort"][req.query.orderBy] = 1;
        } else {
            pagination["sort"][req.query.orderBy] = -1;
        }
    }

    let end_date = new Date(req.query.endDate);
    end_date = new Date(end_date).setHours(23, 59, 59, 999);
    end_date = new Date(end_date);
    let query = {
        userType: "consultant",
    }

    if (req.query.search) {
        const searchData = new RegExp(req.query.search, 'i')
        query["$or"] = [{ firstName: searchData }, { lastName: searchData }];
    }
    
    const params = {
        pagination: pagination,
        query: query,
        startDate: new Date(req.query.startDate),
        endDate: end_date
    }
    const consultants = await User.userList(params);
    return res.success({consultants});
}

export default service;