import Session from '../../models/session.model.js';
import Feedback from '../../models/feedback.model.js';
import User from '../../models/user.model.js';
import Utility from '../../library/utility.js';

var service = {};

service.sessionList = async (req, res) => {
    const pagination = {
        page: req.query.page ? req.query.page : 1,
        limit: req.query.limit ? req.query.limit : 10,
        populate: [
            {
                path: "consultantId",
                model: User,
                select: "firstName lastName"
            },
            {
                path: "customerId",
                model: User,
                select: "firstName lastName"
            },
        ]
    };

    if(req.query.orderBy){
        pagination["sort"] = {};
        if (req.query.orderDirection == 'asc') {
            pagination["sort"][req.query.orderBy] = 1;
        } else {
            pagination["sort"][req.query.orderBy] = -1;
        }
    }

    const query = {}

    if (req.query.search) {
        const searchData = new RegExp(req.query.search, 'i')
        query["status"] = searchData;
    }

    if (req.query.customerId) {
        query["customerId"] = req.query.customerId;
    }

    if (req.query.consultantId) {
        query["consultantId"] = req.query.consultantId;
        if(req.query.from && req.query.to){
            query["dateTime"] = {
                $gte: new Date(req.query.from),
                $lt: new Date(req.query.to)
            }
        }
        if(req.query.subscription_type){
            query["subscription_type"] = req.query.subscription_type;
        }
    }
    
    const data = await Utility.paginate(Session, query, pagination);

    return res.success({data});
}

service.sessionFeedbacK = async (req, res) => {
    let feedback = await Utility.getOneDb(Feedback, { sessionId: req.query.sessionId });
    return res.success({data: feedback});
}

export default service;