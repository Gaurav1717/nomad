import Country from '../../models/country.model.js';
import State from '../../models/state.model.js';
import City from '../../models/city.model.js';
// import countries from './../../nomad_city_state_countr/countries.json';
// import states from './../../nomad_city_state_countr/states.json';
// import cities from './../../nomad_city_state_countr/cities.json';
const axios = require('axios');
import Utility from '../../library/utility.js';
var csv = require('node-csv').createParser();

var service = {};

service.upload_country_state_city = async (req, res) => {
    // var country_map = {};
    // var state_map = {};
    
    /* Please Do not open the code */

    // for(const country of countries){
    //     const addedCountry = await Utility.addDb(Country, {
    //         sortname: country.iso2,
    //         name: country.name,
    //         phone_code: country.phone_code,
    //     });

    //     country_map[country.id] = addedCountry._id;

    //     console.log("country", country.id);
    // }

    // for(const state of states){
    //     const addedState = await Utility.addDb(State, {
    //         countryId: country_map[state.country_id],
    //         name: state.name,
    //     });

    //     state_map[state.id] = addedState._id;

    //     console.log("state", state.id);
    // }

    // for(const city of cities){
    //     await Utility.addDb(City, {
    //         countryId: country_map[city.country_id],
    //         stateId: state_map[city.state_id],
    //         name: city.name,
    //     });

    //     console.log("city", city.id);
    // }

    return res.success({});    
}

export default service;