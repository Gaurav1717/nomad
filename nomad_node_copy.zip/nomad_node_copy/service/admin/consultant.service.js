import User from '../../models/user.model.js';
import Country from '../../models/country.model.js';
import Utility from '../../library/utility.js';
import Availability from '../../models/availability.model.js';
import Session from '../../models/session.model.js';
import DemoSession from '../../models/bookSession.model.js';
import jwt from 'jsonwebtoken';
const bcrypt = require('bcrypt');

var service = {};

service.addConsultant = async (req, res) => {
    // Get user input
    const { firstName, lastName, email, password, phone, consultantCountries, gender} = req.body;

    const query = { email: req.body.email}

    // check if user already exist
    const oldUser = await Utility.getOneDb(User, query);
    if (oldUser) {
        return res.error({ "errorMsg": "User Already Exist. Please Login." });
    }

    //Encrypt user password
    const encryptedPassword = await bcrypt.hash(password, 8);

    var token = jwt.sign({email: email}, process.env.JWT_SECRET);

    const link = process.env.BASE_URL+ "/reset-password/"+token;

    const languages = req.body.languages ? req.body.languages : [];

    // Create user in our database
    const user = await User.create({
        firstName,
        lastName,
        phone,
        consultantCountries,
        gender,
        email: email.toLowerCase(), // sanitize: convert email to lowercase
        password: encryptedPassword,
        confirmationCode: token,
        emailVerified: true,
        userType: 'consultant',
        languages: languages,
        zoomUserId: "CsTow2yXQqyUU1xUUOGhqQ",
    });
    
    const userData = {
        firstName: user.firstName,
        lastName: user.lastName,
        phone: user.phone,
        consultantCountries: user.consultantCountries,
        gender: user.gender,
        email: user.email,
        password: req.body.password,
        link: link
    }
    
    const params = {
        to: req.body.email,
        subject: user.firstName +' / '+ 'Nomad Grab Intro',
        content: userData,
        template: "consultant_created.html"
    };

    await Utility.sendMail(params);
    return res.success({msg: "Created successfully!!"});
}

service.updateConsultant = async (req, res) => {
    const languages = req.body.languages ? req.body.languages : [];
    const updateData = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        phone: req.body.phone,
        consultantCountries: req.body.consultantCountries,
        gender: req.body.gender,
        languages: languages,
    };

    if (req.body.lastName) {
        updateData.lastName;
    }

    const query = { _id: req.body._id };
    const set = { "$set": updateData };
    await Utility.updateDb(User, query, set);

    return res.success({msg: "Updated successfully!!"}); 
 }

service.consultantList = async (req, res) => {
    let pagination = {
        page: req.query.page ? req.query.page : 1,
        limit: req.query.limit ? req.query.limit : 10,
        populate: {
            path: "consultantCountries",
            model: Country,
            select: "name"
        }
    };

    if(req.query.orderBy){
        pagination["sort"] = {};
        if (req.query.orderDirection == 'asc') {
            pagination["sort"][req.query.orderBy] = 1;
        } else {
            pagination["sort"][req.query.orderBy] = -1;
        }
    }

    const query = {userType: "consultant"}

    if (req.query.search) {
        const searchData = new RegExp(req.query.search, 'i')
        query["$or"] = [{ firstName: searchData }, { lastName: searchData }, { email: searchData }, { phone: searchData }, { languages: searchData }];
    }

    if(req.query.countryId){
        query['consultantCountries'] = req.query.countryId;
    }

    if(req.query.languages){
        query['languages'] = req.query.languages;
    }

    const data = await Utility.paginate(User, query, pagination);

    return res.success({data});
}

service.changeStatus = async (req, res) => {
    let editTOStatus = {
        status: req.body.status ? req.body.status : "",
    };
    let query = { _id: req.body._id ? req.body._id : '' };
    let set = { "$set": editTOStatus };
    const editStatus = await Utility.updateDb(User, query, set);
    return res.success({msg: "Status chenged successfully!!"});
}

service.consultantAvailability = async ( req, res )=> {
    const search_start_date = req.body.startTime;
    const search_end_date = req.body.endTime;
    
    const query = {
        "consultantId": req.body.consultantId,
        "startTime": { "$gte": search_start_date, "$lte": search_end_date },
        "endTime": {"$gte": search_start_date, "$lte": search_end_date }
    };
    const consultantAvailability = await Utility.findDb(Availability, query); 
    
    const sessionQuery = { status: "scheduled", "dateTime": { "$gte": search_start_date, "$lte": search_end_date }, consultantId: req.body.consultantId };
    let sessions = await Utility.findDb(Session, sessionQuery); 
    
    const consultantDemoSessionAvailability = await Utility.findDb(DemoSession, sessionQuery); 
    sessions = sessions.concat(consultantDemoSessionAvailability);

    return res.success({data: consultantAvailability, sessions: sessions});
}

service.allConsultants = async(req, res) => {
    const query = {userType: "consultant", status: "active"}
    const data = await Utility.findDb(User, query);
    return res.success({data});
}

service.deleteConsultant = async(req, res) => {
    let _id = req.query._id
    if(!_id){
        return res.error({ "errorMsg": "_id query params is required" });
    }
    const query = { _id: _id};
    await Utility.deleteDb(User, query);
    return res.success({msg: "Deleted successfully!!"}); 
}

service.resentEmailConsultant = async (req, res) => {
    let _id = req.query._id
    if(!_id){
        return res.error({ "errorMsg": "_id query params is required" });
    }
    const query = { _id: _id};
    const user = await Utility.getOneDb(User, query);
    if(!user){
        return res.error({ "errorMsg": "Consultant Not Found" });
    }
    const userData = {
        firstName: user.firstName,
        lastName: user.lastName,
        phone: user.phone,
        consultantCountries: user.consultantCountries,
        gender: user.gender,
        email: user.email,
        password: '-'
    }
    
    const params = {
        to: user.email,
        subject: "Welcome to Nomad Grab - Resent Confirmation",
        content: userData,
        template: "consultant_created.html"
    };

    await Utility.sendMail(params);
    return res.success({msg: "Resent Confirmation Email Sent!"});
}

service.detailConsulant = async (req, res) => {
    let _id = req.query._id
    if(!_id){
        return res.error({ "errorMsg": "_id query params is required" });
    }
    const query = { _id: _id};
    const user = await Utility.getOneDb(User, query);
    if(!user){
        return res.error({ "errorMsg": "Consultant Not Found" });
    }
    return res.success({data: user});
}
export default service;