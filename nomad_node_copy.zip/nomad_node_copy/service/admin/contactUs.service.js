import contactUs from '../../models/contactus.model.js';
import Utility from '../../library/utility.js';

var service = {};

service.contactUsList = async (req, res) => {
    let pagination = {
        page: req.query.page ? req.query.page : 1,
        limit: req.query.limit ? req.query.limit : 10,
    };

    if(req.query.orderBy){
        pagination["sort"] = {};
        if (req.query.orderDirection == 'asc') {
            pagination["sort"][req.query.orderBy] = 1;
        } else {
            pagination["sort"][req.query.orderBy] = -1;
        }
    }

    const query = {};

    if (req.query.search) {
        const searchData = new RegExp(req.query.search, 'i')
         query["$or"] = [ { firstName: searchData }, { lastName: searchData }, { email: searchData }];
    }

    const data = await Utility.paginate(contactUs, query, pagination);
    return res.success({data});
}

export default service;