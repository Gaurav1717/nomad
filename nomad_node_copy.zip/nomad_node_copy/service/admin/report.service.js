import Report from '../../models/report.model.js';
import User from '../../models/user.model.js';
import Utility from '../../library/utility.js';

var service = {};

service.reportList = async (req, res) => {
    let pagination = {
        page: req.query.page ? req.query.page : 1,
        limit: req.query.limit ? req.query.limit : 10,
        populate: {
            path: "customerId",
            model: User,
            select: "firstName lastName"
        }
    };

    if(req.query.orderBy){
        pagination["sort"] = {};
        if (req.query.orderDirection == 'asc') {
            pagination["sort"][req.query.orderBy] = 1;
        } else {
            pagination["sort"][req.query.orderBy] = -1;
        }
    }

    const query = {}

    if (req.query.customerId) {
        query["customerId"] = req.query.customerId;
    }

    const data = await Utility.paginate(Report, query, pagination);
    return res.success({data});
}

export default service;