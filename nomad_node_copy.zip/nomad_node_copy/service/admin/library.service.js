import Library from '../../models/library.model';
import Country from '../../models/country.model';
import City from '../../models/city.model';
import Utility from '../../library/utility.js';
var service = {};

service.addLibrary = async (req, res) => {
  const { countryId, cityId, whatsapp_link, group_name, activity_level, category} = req.body;
  await Library.create({
    countryId,
    cityId,
    whatsapp_link,
    group_name,
    activity_level,
    category
  });

  return res.success({msg: "Library created successfully!!"});
}

service.listLibrary = async (req, res) => {
  let pagination = {
    page: req.query.page ? req.query.page : 1,
    limit: req.query.limit ? req.query.limit : 10,
    populate: [{
      path:"countryId",
      select :"name",
      model:Country
    },
    {
      path:"cityId",
      select :"name",
      model:City
    }]
  };
  
  if(req.query.orderBy){
    pagination["sort"] = {};
    if (req.query.orderDirection == 'asc') {
        pagination["sort"][req.query.orderBy] = 1;
    } else {
        pagination["sort"][req.query.orderBy] = -1;
    }
  }

  const query = {};
  
  if (req.query.search) {
    const searchData = new RegExp(req.query.search, 'i')
    query["group_name"] = searchData;
  }

  if(req.query.countryId){
    query['countryId'] = req.query.countryId;
  }

  if(req.query.cityId){
    query['cityId'] = req.query.cityId;
  }

  const data = await Utility.paginate(Library, query, pagination);

  return res.success({data});

}

service.changeStatus = async(req, res) => {
  const libraryData = {
    status: req.body.status ? req.body.status : 'active',
  };

  let query = {
      _id: req.body._id ? req.body._id : ''
  };

  let set = { "$set": libraryData };
  await Utility.updateDb(Library, query, set);
  return res.success({msg: "Status chenged successfully!!"});
}
export default service;