import Report from '../../models/report.model.js';
import User from '../../models/user.model.js';
import Language from '../../models/language.model.js';
import contactUs from '../../models/contactus.model.js';
import Session from '../../models/session.model.js';
import demoSession from '../../models/bookSession.model.js';
import Library from '../../models/library.model';
import Utility from '../../library/utility.js';

var service = {};

service.dashboard = async (req, res) => {
    let data = {};

    //Customer
    data.customerCount = await Utility.getCount(User, { userType: "customer" });

    //Consultant
    data.consultantCount = await Utility.getCount(User, { userType: "consultant" });

    //Language
    data.languageCount = await Utility.getCount(Language);

    //Completed Session
    data.completedSessionCount = await Utility.getCount(Session, { status: "completed" });

    //Scheduled Session
    data.scheduledSessionCount = await Utility.getCount(Session, { status: "scheduled" });

    //Completed Demo Session
    data.completedDemoSessionCount = await Utility.getCount(demoSession, { status: "completed" });

    //Scheduled Demo Session
    // data.scheduledDemoSessionCount = await Utility.getCount(demoSession, { status: "scheduled" });

    //Cancelled Demo Session
    // data.cancelledDemoSessionCount = await Utility.getCount(demoSession, { status: "cancelled" });

    //Booked Demo Session
    data.bookedDemoSessionCount = await Utility.getCount(demoSession, { status: "booked" });

    //Help
    data.contactUsCount = await Utility.getCount(contactUs);

    //report
    data.reportCount = await Utility.getCount(Report);

    //Library
    data.libraryCount = await Utility.getCount(Library, { status: "active" });
    
    res.success({data});
}

export default service;