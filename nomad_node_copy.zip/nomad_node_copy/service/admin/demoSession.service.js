import demoSession from '../../models/bookSession.model.js';
import Session from '../../models/session.model.js';
import User from '../../models/user.model.js';
import Utility from '../../library/utility.js';
import axios from 'axios';
import moment from 'moment-timezone';
//var moment = require('moment-timezone');

var service = {};

service.demoSessionList = async (req, res) => {
    const pagination = {
        page: req.query.page ? req.query.page : 1,
        limit: req.query.limit ? req.query.limit : 10,
        populate: {
            path: "consultantId",
            model: User,
            select: "firstName lastName"
        }
    };

    if(req.query.orderBy){
        pagination["sort"] = {};
        if (req.query.orderDirection == 'asc') {
            pagination["sort"][req.query.orderBy] = 1;
        } else {
            pagination["sort"][req.query.orderBy] = -1;
        }
    }

    const query = {};

    if (req.query.search) {
        const searchData = new RegExp(req.query.search, 'i')
         query["$or"] = [ { firstName: searchData }, { lastName: searchData }];
    }

    if (req.query.consultantId) {
        query["consultantId"] = req.query.consultantId;
    }

    const data = await Utility.paginate(demoSession, query, pagination);
    
    return res.success({data});
}

service.changeDemoSessionStatus = async (req, res) => {
    const demoSessionStatus = {
        status: req.body.status ? req.body.status : '',
    };

    let query = {
        _id: req.body._id ? req.body._id : ''
    };

    const user = await Utility.getOneDb(demoSession, {_id: req.body._id});

    const demoSessionStatusEmail = {
        userName: user.firstName +' '+ user.lastName,
    }

    const params = {
        to: user.email,
        subject: "Cancelled Session",
        content: demoSessionStatusEmail,
        template: "cancelled _demo_session.html"
    };
    await Utility.sendMail(params);
    let set = { "$set": demoSessionStatus };
    await Utility.updateDb(demoSession, query, set);

    return res.success({msg: "Status chenged successfully!!"});
}

service.scheduleDemoSession = async ( req, res )=> {
    const demoSessionId =  req.body._id;
    const userSession = await Utility.getOneDb(demoSession, {_id: demoSessionId});
    const consultantId = req.body.consultantId;
    const sessionQuery = {status: "scheduled", dateTime: req.body.dateTime, consultantId: req.body.consultantId };
    const isSessionBooked = await Utility.getOneDb(Session, sessionQuery);

    if (isSessionBooked) {
        return res.error({ "errorMsg": "Please choose another slot." });
    }

    /* Zoom Meeting */
    const consultantData = await Utility.getOneDb(User, {_id: consultantId});

    const options = {
        url: process.env.ZOOM_BASE_LINK+"/users/me/meetings",
        method: "POST",
        data: {
            "agenda": "Class",
            "default_password": false,
            "duration": 45,
            "settings": {
                "join_before_host": true,
                "waiting_room": false
            },
            "allow_multiple_devices": true,
            "tracking_fields": [
                {
                    "field": "meeting_type",
                    "value": "demo_session"
                }
            ],
        },
        headers: {
            "Authorization": process.env.ZOOM_JWT,
            "Content-Type": "application/json"
        }
    };

    const createMeeting = await axios(options);

    const inviteOptions = {
        url: process.env.ZOOM_BASE_LINK+"/meetings/"+createMeeting.data.id+"/invite_links",
        method: "POST",
        data: {
            "attendees": [
                {
                    "name": req.user.firstName
                }
            ],
            "ttl": 1000
        },
        headers: {
            "Authorization": process.env.ZOOM_JWT,
            "Content-Type": "application/json"
        }
    };

    const inviteMeeting = await axios(inviteOptions);

    let customerZoomLink = "";
    inviteMeeting.data.attendees.map(item => {
        customerZoomLink = item.join_url;
    });
    /* /Zoom Meeting */

    const { dateTime } = req.body;

    const demoSessionData = {
        consultantId: consultantId,
        status: 'scheduled',
        dateTime,
        zoomId: createMeeting.data.id,
        consultantZoomLink: createMeeting.data.start_url,
        customerZoomLink: customerZoomLink,
    };

    const timeZone = moment.tz(dateTime,"America/Los_Angeles").format("ddd, MMM D hh:mm A")+" PDT";

    const userEmailDemoSession = {
        userName: userSession.firstName +' '+ userSession.lastName,
        consultantName: consultantData.firstName +' '+ consultantData.lastName,
        timZone: timeZone,
        zoomLink: customerZoomLink,
        zoomId: demoSessionData.zoomId
    }

    const userParams = {
        to: userSession.email,
        subject: "Demo session",
        content: userEmailDemoSession,
        template: "user_demo_session.html"
    };

    const consultantEmailDemoSession = {
        userName: userSession.firstName +' '+ userSession.lastName,
        userEmail: userSession.email,
        company: userSession.company,
        description: userSession.description,
        timZone: timeZone,
        consultantZoomLink: createMeeting.data.start_url,
        zoomId: demoSessionData.zoomId
    }

    const consultParams = {
        to: consultantData.email,
        subject: "Demo session",
        content: consultantEmailDemoSession,
        template: "consultant_demo_session.html"
    };

    await Utility.sendMail(userParams);
    await Utility.sendMail(consultParams);

    let query = {
        _id: demoSessionId ? demoSessionId : ''
    };

    await Utility.updateDb(demoSession, query, demoSessionData);
    return res.success({msg: 'Demo session scheduled successfully!!'});
}

export default service;