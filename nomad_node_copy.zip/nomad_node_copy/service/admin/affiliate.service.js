import User from '../../models/user.model.js';
import Utility from '../../library/utility.js';
const bcrypt = require('bcrypt');

var service = {};

service.addAffiliate = async (req, res) => {
    const { firstName, lastName, email, phone} = req.body;

    const query = { email: req.body.email}

    const oldUser = await Utility.getOneDb(User, query);
    if (oldUser) {
        return res.error({ "errorMsg": "Affiliate already exist." });
    }

    await User.create({
        firstName,
        lastName,
        email,
        phone,
        userType: 'affiliate',
    });

    return res.success({msg: "Created successfully!!"});
}

service.updateAffiliate = async (req, res) => {
    const updateData = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        phone: req.body.phone
    };

    if (req.body.lastName) {
        updateData.lastName;
    }

    const query = { _id: req.body._id };
    const set = { "$set": updateData };
    await Utility.updateDb(User, query, set);

    return res.success({msg: "Updated successfully!!"}); 
}

service.affiliateList = async (req, res) => {
    const page = req.query.page?parseInt(req.query.page):1;
    let pagination = {
        page: page ? (page !=0 ? page-1:0) : 0,
        limit: req.query.limit ? parseInt(req.query.limit) : 10,
    };

    if(req.query.orderBy){
        pagination["sort"] = {};
        if (req.query.orderDirection == 'asc') {
            pagination["sort"][req.query.orderBy] = 1;
        } else {
            pagination["sort"][req.query.orderBy] = -1;
        }
    }

    const query =  {  userType: 'affiliate' };

    if (req.query.search) {
        const searchData = new RegExp(req.query.search, 'i')
        query["firstName"] = searchData;
    }

    const affiliateUser = await Utility.findDb(User, query);
    const affiliateId = [];
    for (let user of affiliateUser) {
        affiliateId.push(user._id);
    }
    
    const params = {
        pagination: pagination,
        query: query,
    }

    const affiliateUserRes = await User.affiliateList(params);
    return res.success({affiliateUserRes});

}

export default service;