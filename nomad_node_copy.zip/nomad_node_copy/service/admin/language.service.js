import Language from '../../models/language.model.js';
import Utility from '../../library/utility.js';
var service = {};

service.add = async (req, res) => {
    try {
        // Get laguage input
        const langName = req.body.langName.trim();
    
        let query = { langName: langName};

        // check if laguage already exist
        let oldlaguage = await Utility.getOneDb(Language, query);
    
        if (oldlaguage) {
          return res.error({ "errorMsg": "Language Already Exist." });
        }
    
        // Create laguage in our database
        await Language.create({
            langName,
        });
    
        return res.success({msg: "Language created successfully!!"});
    } catch (err) {
    return res.error({errorMsg: "Something is wrong!"});
    }
}

service.update = async (req, res) => {
    const langName = req.body.langName.trim();
    const langData = {
        langName: langName,
    };

    const query = {
        _id: req.body._id ? req.body._id : ''
    };
    const set = { "$set": langData };
    await Utility.updateDb(Language, query, set);
    return res.success({msg: "Language updated successfully!!"});
}

service.changeStatus = async (req, res) => {
    const langData = {
        status: req.body.status ? req.body.status : 'active',
    };

    let query = {
        _id: req.body._id ? req.body._id : ''
    };

    let set = { "$set": langData };
    await Utility.updateDb(Language, query, set);
    return res.success({msg: "Status chenged successfully!!"});
}

service.list = async (req, res) => {
    let pagination = {
        page: req.query.page ? req.query.page : 1,
        limit: req.query.limit ? req.query.limit : 10,
    };

    if(req.query.orderBy){
        pagination["sort"] = {};
        if (req.query.orderDirection == 'asc') {
            pagination["sort"][req.query.orderBy] = 1;
        } else {
            pagination["sort"][req.query.orderBy] = -1;
        }
    }
    const query = {}

    if (req.query.search) {
        const searchData = new RegExp(req.query.search, 'i')
        query["langName"] = searchData;
    }

    const data = await Utility.paginate(Language, query, pagination);
    return res.success({data});
}

export default service;