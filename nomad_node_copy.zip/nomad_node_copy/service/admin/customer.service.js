import User from '../../models/user.model.js';
import Country from '../../models/country.model.js';
import Utility from '../../library/utility.js';
import Feedback from '../../models/feedback.model';
import Payment from '../../models/payment.model';
import Report from '../../models/report.model';
import Session from '../../models/session.model';
import Subscription from '../../models/session.model';

var service = {};

service.customerList = async (req, res) => {
    var contryObj = {};
    var contryIds = [];
    let pagination = {
        page: req.query.page ? req.query.page : 1,
        limit: req.query.limit ? req.query.limit : 10,
        populate: {
            path: "country",
            model: Country,
            select: "name"
        }
    };

    if(req.query.orderBy){
        pagination["sort"] = {};
        if (req.query.orderDirection == 'asc') {
            pagination["sort"][req.query.orderBy] = 1;
        } else {
            pagination["sort"][req.query.orderBy] = -1;
        }
    }

    let query = {userType: "customer"}

    if (req.query.search) {
        const searchData = new RegExp(req.query.search, 'i')
        query["$or"] = [{ firstName: searchData }, { lastName: searchData }, { email: searchData }, { phone: searchData }];
    }

    if(req.query.affiliateId){
        query['affiliateId'] = req.query.affiliateId;
        query['firstSubscriptionType'] = {"$in": ["monthly", "single"]};
    }

    if(req.query.country){
        query['country'] = req.query.country;
    }
        
    const data = await Utility.paginate(User, query, pagination);

    return res.success({data});
}

service.allCustomers = async(req, res) => {
    const query = {userType: "customer", status: "active"}
    const data = await Utility.findDb(User, query);
    return res.success({data});
}

service.customersDelete = async(req, res) => {
    await Utility.deleteDb(User, { _id: req.body.id });
    await Utility.deleteDb(Feedback, { customerId: req.body.id });
    await Utility.deleteDb(Payment, { customerId: req.body.id });
    await Utility.deleteDb(Report, {customerId: req.body.id });
    await Utility.deleteDb(Session, { customerId: req.body.id });
    await Utility.deleteDb(Subscription, { customerId: req.body.id });
    return res.success({msg: "Customer deleted successfully!!"});
}

export default service;