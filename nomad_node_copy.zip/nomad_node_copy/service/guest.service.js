const DemoSessionModel = require('../models/bookSession.model.js');
const UserModel = require('../models/user.model.js');
import Utility from '../library/utility.js';
const Contactus = require('../models/contactus.model.js');
const Language = require('../models/language.model.js');
var service = {};

service.addContactUs = async (req, res) => {
    const data = await Contactus.create({
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        message: req.body.message,
    });

    let params = {
        to: process.env.ADMIN_MAIL,
        subject: "Cantact Us",
        content: data,
        template: "contact_us.html"
    };
    
    await Utility.sendMail(params);
    return res.success({msg: "Created successfully!!"});
}

service.requestDemo = async (req, res) => {
    let addData = req.body;
    let email = req.body.email.toLowerCase();

    if(req.body.email){
        const old_email = await Utility.getOneDb(DemoSessionModel, {email: email});
        const user_email = await Utility.getOneDb(UserModel, {email: email});
        if(old_email || user_email){
            return res.error({
                errorMsg: 'Email already exist!!'
            });
        }
    }

    var newDemoSession = {
        firstName:addData.firstName, 
        lastName:addData.lastName ? addData.lastName: '', 
        email:email, 
        company:addData.company,
        description:addData.description,
        country:addData.country
    };

    await Utility.addDb(DemoSessionModel, newDemoSession);
   
    let adminParams = {
        to: process.env.MAIL_FROM,
        subject: "Demo Session Request",
        content: newDemoSession,
        template: "request_session.html"
    };

    let userParams = {
        to: req.body.email,
        subject: "Demo Session Request",
        content: newDemoSession,
        template: "book_demo_session.html"
    };

    await Utility.sendMail(adminParams);
    await Utility.sendMail(userParams);

    return res.success({});
};

service.demoSessionUserInfo = async (req, res) => {
    // Get user input
    const { email } = req.body;

    // Validate if user exist in our database
    const userInfo = await Utility.getOneDb(DemoSessionModel,{ email });
    if(userInfo) {
    let demoSessionUserInfo = {
        firstName: userInfo.firstName,
        lastName: userInfo.lastName,
        email: userInfo.email,
        company: userInfo.company,
        description: userInfo.description
        }
        return res.success({data: demoSessionUserInfo});
    }
    return res.error({errorMsg: "Invalid email!!"}); 
}

service.languageList = async (req, res) => {
    const language = await Utility.findDb(Language, {status: "active"});
    return res.send({data: language});
}

service.health = async (req, res) => {
    return res.send({data: 'Nomad API Working...'});
}

export default service;