import axios from 'axios';
import qs from 'qs';
import Payment from '../../models/payment.model.js';
import Subscription from '../../models/subscription.model.js';
import User from '../../models/user.model.js';
import Utility from '../../library/utility.js';

var service = {};

service.verifyPayment = async ( req, res ) => {
    const trasactionId = req.body.trasactionId;
    let subscription_type = req.body.subscription_type
    
    const oldPayment = await Utility.getOneDb(Payment, {"trasactionId": trasactionId});
    if(oldPayment){
        return res.error({"errorMsg": "Payment already completed."});
    }

    const session_token = await Utility.paypalAccessToken();
    let url = process.env.PAYPAL_ORDER_URL+"/"+trasactionId // single order
    if(subscription_type === 'monthly'){
        url = process.env.PAYPAL_SUBSCRIPTION_URL+"/"+trasactionId
    }
    const options = {
        url: url,
        method: "GET",
        headers: {
            'Authorization': 'Bearer '+session_token
        }
    };
    const paypalRes = await axios(options);
    let amount;
    if(subscription_type === 'monthly'){
        amount = paypalRes.data.billing_info.last_payment.amount;
    }else{
        amount = paypalRes.data.purchase_units[0].amount;
    }

    // amount.currency_code == "USD" && parseInt(amount.value) == 60
    if(amount.currency_code == "USD" && parseInt(amount.value) >= 0){
        const paymentData = {
            customerId: req.user._id,
            trasactionId: trasactionId,
            currency_code: amount.currency_code,
            value: amount.value,
            payload: paypalRes.data
        }
        const paymentSaved = await Utility.addDb(Payment, paymentData);

        let subscriptionStatus = "running";
        let startDate = new Date();
        let endDate;
        let monthEndDate = new Date();
        if(subscription_type === 'monthly'){
            endDate = monthEndDate.setDate(monthEndDate.getDate() + 30);
        } else {
            endDate = '';
        }

        const last_subscription = await Utility.getOneDb(Subscription, {customerId: req.user._id}, {"createdAt": -1});
        if(last_subscription){
            if(last_subscription.status != "expired"){
                subscriptionStatus = "running";

                // startDate = new Date(last_subscription.endDate);
                // endDate = new Date(last_subscription.endDate);
                // endDate.setDate(endDate.getDate() + 30);
            }
        } else {
            const user = await Utility.getOneDb(User, {status: "active", _id: req.user._id});
            if(user.affiliateId){
                const updateData = {
                    firstSubscriptionType: subscription_type,
                    firstSubscriptionDate: new Date()
                };
    
                const query = { _id: user._id };
                const set = { "$set": updateData };
                await Utility.updateDb(User, query, set);
            }
        }

        const subscriptionData = {
            customerId: req.user._id,
            paymentId: paymentSaved._id,
            trasactionId: trasactionId,
            amount: amount.value,
            startDate: startDate,
            endDate: endDate,
            remainingSession: 0,
            status : subscriptionStatus,
            subscription_type: subscription_type,
        }

        if(subscription_type === 'monthly'){
            subscriptionData.recurance = true;
        }

        await Utility.addDb(Subscription, subscriptionData);
    }

    return res.success();
}

service.cancelPayment = async (req, res) => {
    const subscription = await Utility.getOneDb(Subscription, {customerId: req.user._id, status: {"$ne": "expired",}, subscription_type: "monthly"}, {"createdAt": -1});

    if(subscription){
        const session_token = await Utility.paypalAccessToken();
        const url = process.env.PAYPAL_SUBSCRIPTION_URL+"/"+subscription.trasactionId+"/"+'cancel';

        const options = {
            url: url,
            method: "POST",
            data:{
                'reason': 'Not satisfied with the service'
            },
            headers: {
                'Authorization': 'Bearer '+session_token
            }
        };
        
        await axios(options).catch((err, res) => {
            console.log("err, res", err, res)
        });

        let changeStatus = {
            recurance : false
        }

        let subscriptionData = {
            query: { customerId: req.user._id },
            set: { "$set": changeStatus }
        }

        await Utility.updateDb(Subscription, subscriptionData.query, subscriptionData.set);
    }
    return res.success({msg: 'Subscription cancelled successfully!!'});

}

service.discountPayment = async (req, res) => {
    const subscription = await Utility.getOneDb(Subscription, {customerId: req.user._id, status: {"$ne": "expired"}}, {"createdAt": -1});
    if(subscription){
        const session_token = await Utility.paypalAccessToken();
        const url = process.env.PAYPAL_SUBSCRIPTION_URL+"/"+subscription.trasactionId+"/"+'revise';
        
        const options = {
            url: url,
            method: "POST",
            data:{
                "plan_id": process.env.PAYPAL_DISCOUNT_PLAN_ID
            },
            headers: {
                'Authorization': 'Bearer '+session_token
            }
        };

        await axios(options).catch((err, res) => {
            console.log("err, res", err, res)
        });

        let changeStatus = {
            discount_status : true
        }

        let subscriptionData = {
            query: { _id: req.user._id },
            set: { "$set": changeStatus }
        }

        await Utility.updateDb(User, subscriptionData.query, subscriptionData.set);
        // await Utility.updateDb(Subscription, subscriptionData.query, subscriptionData.set);
    }
    return res.success({msg: 'Discount applied successfully!!'});
}

export default service;