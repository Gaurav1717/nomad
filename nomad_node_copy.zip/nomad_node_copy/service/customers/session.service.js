import axios from 'axios';
import Session from '../../models/session.model.js';
import demoSession from '../../models/bookSession.model.js';
import Subscription from '../../models/subscription.model.js';
import User from '../../models/user.model.js';
import Utility from '../../library/utility.js';
import moment from 'moment-timezone';
var service = {};

service.session = async ( req, res )=> {
    try {
        const customerId = req.user._id;
        const subscription = await Utility.getOneDb(Subscription, {customerId: req.user._id, status: { "$ne": "expired" }, subscription_type: "single"}, {"createdAt": 1});
        const consultantId = req.body.consultantId;
        // if(!subscription){
        //     return res.error({ "errorMsg": "You don't have active subscription. Please buy a subscription." });
        // }

        const query = { language: req.body.language, dateTime: req.body.dateTime, status: "scheduled", "$or":[{ customerId: customerId }, {consultantId: consultantId}]};
        const oldSession = await Utility.getOneDb(Session, query);

        if (oldSession) {
            return res.error({ "errorMsg": "Slot not available." });
        }   

        const sessionQuery = { status: "scheduled", dateTime: req.body.dateTime, consultantId: consultantId };
        const isSessionBooked = await Utility.getOneDb(demoSession, sessionQuery);

        if (isSessionBooked) {
            return res.error({ "errorMsg": "Please choose another slot." });
        }

        /* Zoom Meeting */

        const session_token = await Utility.zoomAccessToken();
        const options = {
            url: process.env.ZOOM_BASE_LINK+"/users/me/meetings",
            method: "POST",
            data: {
                "agenda": "Class",
                "default_password": false,
                "duration": 45,
                "settings": {
                    "join_before_host": true,
                    "waiting_room": false
                },
                "allow_multiple_devices": true,
                "tracking_fields": [
                    {
                      "field": "meeting_type",
                      "value": "session"
                    }
                ],
            },
            headers: {
                'Authorization': 'Basic '+session_token
            }
            // headers: {
            //     "Authorization": process.env.ZOOM_JWT,
            //     "Content-Type": "application/json"
            // }
        };
        const createMeeting = await axios(options);
        console.log('createMeeting', createMeeting);return'545435353';

        const inviteOptions = {
            url: process.env.ZOOM_BASE_LINK+"/meetings/"+createMeeting.data.id+"/invite_links",
            method: "POST",
            data: {
                "attendees": [
                    {
                        "name": req.user.firstName
                    }
                ],
                "ttl": 1000
            },
            headers: {
                "Authorization": process.env.ZOOM_JWT,
                "Content-Type": "application/json"
            }
        };

        const inviteMeeting = await axios(inviteOptions);

        let customerZoomLink = "";
        inviteMeeting.data.attendees.map(item => {
            customerZoomLink = item.join_url;
        });
        /* /Zoom Meeting */
        
        const { language, dateTime } = req.body;
        
        const date = req.body.slotDateFormatted;
        const time = req.body.slotTimeFormatted;
        const subscription_type = subscription.subscription_type
        const bookSession = await Session.create({
            customerId,
            consultantId,
            language,
            dateTime,
            slotDate: date,
            slotTime: time,
            zoomId: createMeeting.data.id,
            consultantZoomLink: createMeeting.data.start_url,
            customerZoomLink: customerZoomLink,
            subscription_type: subscription_type
        });
        
        if(subscription_type === 'single'){
            await Utility.updateDb(Subscription, {
                _id: subscription._id
            },{
                remainingSession: 0,
                status: "expired"
            });    
        }
        const emailSession = {
            customerName: req.user.firstName +' '+ req.user.lastName,
            date: date,
            time: time,
            language: bookSession.language,
            zoomLink: customerZoomLink,
            zoomId: bookSession.zoomId
        }

        const params = {
            to: req.user.email,
            subject: "Session",
            content: emailSession,
            template: "book_session.html"
        };
        await Utility.sendMail(params);

        return res.success({msg: 'Session booked successfully!!'});
    } catch (err) {
        console.log(err)
        return res.error({errorMsg:'Something went wrong!!'})
    }
}

service.sessionList = async (req, res) => {
    try {
        let pagination = {
            page: req.query.page ? req.query.page : 1,
            limit: req.query.limit ? req.query.limit : 10,
            sort: {dateTime: -1},
        };

        const query = {
            customerId: req.user._id,
            type: req.query.type ? req.query.type : 'history',
        }

        if(query.type == 'upcoming'){
            console.log("upcoming")
            query["dateTime"] = {
                $gte: new Date(),
            }
        }else {
            console.log("history")
            query["dateTime"] = {
                $lte: new Date()
            }
        }
        

        const data = await Utility.paginate(Session, query, pagination);
        return res.success({data});
    } catch (err) {
        return res.error({errorMsg:'Something went wrong!!'});
    }
}

service.completedSessionList = async (req, res) => {
    try {
        let pagination = {
            page: req.query.page ? req.query.page : 1,
            limit: req.query.limit ? req.query.limit : 10,
            sort: {dateTime: -1},
        };

        const query = {
            customerId: req.user._id,
            status: "completed",
            is_reviewed: false
        }

        const data = await Utility.paginate(Session, query, pagination);
        return res.success({data});
    } catch (err) {
        return res.error({errorMsg:'Something went wrong!!'});
    }
}

service.cancelSession = async (req, res) => {

    let data = {
        "$set": {
            status: "cancelledByCustomer",
        }
    };

    const sessionQuery = { _id: req.body._id };

    const sessionData = await Utility.getOneDb(Session, {_id: sessionQuery});

    if(sessionData.subscription_type === 'single'){
        const subscription = await Utility.getOneDb(Subscription, {customerId: req.user._id, status: "expired" });

        await Utility.updateDb(Subscription, {
            _id: subscription._id
        },{
            remainingSession: 0,
            status: "running"
        });
    }

    const consultantData = await Utility.getOneDb(User, {_id: sessionData.consultantId});

    const timeZone = moment.tz(sessionData.dateTime,"America/Los_Angeles").format("ddd, MMM D hh:mm A")+" PDT";

    var dataToMail = {
        firstName:consultantData.firstName, 
        lastName:consultantData.lastName, 
        language:sessionData.language, 
        dateTime:timeZone
    };

    let params = {
        to: consultantData.email,
        subject: "Cancelled Session",
        content: dataToMail,
        template: "cancelled_session.html"
    }
    
    await Utility.sendMail(params);
    
    await Utility.updateDb(Session, sessionQuery, data);
    return res.success({msg: 'Session cancelled successfully!!'});
}

service.sessionDetails = async (req, res) => {
    try {
        const session = await Utility.getOneDb(Session, {_id: req.query.sessionId});
        const consultant = await Utility.getOneDb(User, {_id: session.consultantId});
        const consultantName = consultant.firstName +' '+ consultant.lastName ;

        const consultantData = {
            consultantName: consultantName,
            sessionDate: session.dateTime
        }
        return res.success({data: consultantData});
    } catch (err) {
        return res.error({errorMsg:'Something went wrong!!'});
    }
}

export default service;