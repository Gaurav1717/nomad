import User from '../../models/user.model.js';
import Session from '../../models/session.model.js';
import DemoSession from '../../models/bookSession.model.js';
import Availability from '../../models/availability.model.js';
import Utility from '../../library/utility.js';

var service = {};


service.consultantList = async ( req, res )=> {
    try {
        // let lastSession =  await Utility.getOneDb(Session, {customerId: req.user._id});
        // if(!lastSession){
        //     lastSession = await Utility.getOneDb(demoSession, {email: req.user.email});
        // }

        // if(lastSession){
        //     var defaultConsultant = await Utility.getOneDb(User, {_id: lastSession.consultantId});
        // }

        let consultantData = await User.find({languages: req.query.language, consultantCountries: req.query.country, userType: "consultant", status: "active"}, {password: 0});
        return res.success({data: consultantData});
    } catch (err) {
    return res.error({errorMsg:'Something went wrong!!'})
    }
}

service.consultantAvailability = async ( req, res )=> {
    const search_start_date = req.body.startTime;
    const search_end_date = req.body.endTime;
    
    const query = {
        "consultantId": req.body.consultantId,
        "startTime": { "$gte": search_start_date, "$lte": search_end_date },
        "endTime": {"$gte": search_start_date, "$lte": search_end_date }
    };
    let consultantAvailability = await Utility.findDb(Availability, query);

    const sessionQuery = { "$and": [{ status: "scheduled" },{ "dateTime": { "$gte": search_start_date, "$lte": search_end_date } }, {"$or": [ {  consultantId: req.body.consultantId }, {  customerId: req.user._id } ]}] };
    let sessions = await Utility.findDb(Session, sessionQuery); 

    const demoSessionQuery = {status: "scheduled", "dateTime": { "$gte": search_start_date, "$lte": search_end_date }, consultantId: req.body.consultantId };
    const consultantDemoSessionAvailability = await Utility.findDb(DemoSession, demoSessionQuery); 
    sessions = sessions.concat(consultantDemoSessionAvailability);

    return res.success({data: consultantAvailability, sessions: sessions});
}
export default service;