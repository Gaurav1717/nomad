import Language from '../../models/language.model.js';
import User from '../../models/user.model.js';
import Utility from '../../library/utility.js';
var service = {};

service.languageList = async (req, res) => {
    const consultantList = await Utility.findDb(User, {consultantCountries: req.query.country, userType: "consultant", status: "active"});
    var languageList = [];

    for (const consultant of consultantList) {
      languageList = languageList.concat(consultant.languages);
    }
    const langList = new Set(languageList);
    const languages = await Utility.findDb(Language, {langName: {"$in": [...langList]}, status: "active"});
    return res.success({data: languages});
}

export default service;