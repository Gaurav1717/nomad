import Session from '../../models/session.model.js';
import Feedback from '../../models/feedback.model.js';
import User from '../../models/user.model.js';
import Utility from '../../library/utility.js';

var service = {};

service.sessionFeedback = async ( req, res )=> {
    try {
        const { tags, progress, ratings, about_situation, address_situation, skill_strategy, checkbox } = req.body;
        const sessionQuery = { _id: req.body.sessionId };

        const sessionData = await Utility.getOneDb(Session, {_id: sessionQuery});
        const consultant = await Utility.getOneDb(User, {_id: sessionData.consultantId});
        const consultantName = consultant.firstName +' '+ consultant.lastName ;

        const consultantData = {
            consultantName: consultantName,
            sessionDate: sessionData.dateTime
        }

        const sessionReview = {
            is_reviewed: true,
        };
    
        let sessionIdQuery = {
            _id: sessionQuery
        };
    
        let set = { "$set": sessionReview };
        await Utility.updateDb(Session, sessionIdQuery, set);
        
        const query = { sessionId: sessionData._id}

        const oldFeedback = await Utility.getOneDb(Feedback, query);
        
        if (oldFeedback) {
            return res.error({ "errorMsg": "You have already given feedback." });
        }
        
        await Feedback.create({
            sessionId: sessionData._id,
            customerId: sessionData.customerId, 
            consultantId: sessionData.consultantId,
            tags,
            progress,
            ratings,
            about_situation,
            address_situation,
            skill_strategy,
            checkbox: checkbox ? checkbox : false,
        });
        
        return res.success({consultantData});
    } catch (err) {
        return res.error({errorMsg:'Something went wrong!!'})
    }
}

export default service;