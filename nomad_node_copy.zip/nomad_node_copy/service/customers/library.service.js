import Library from '../../models/library.model';
import Utility from '../../library/utility.js';
import Country from '../../models/country.model';
import City from '../../models/city.model';
var service = {};

service.libraryList = async (req, res) => {
  let pagination = {
    page: req.query.page ? req.query.page : 1,
    limit: req.query.limit ? req.query.limit : 10,
  };
  
  if(req.query.orderBy){
    pagination["sort"] = {};
    if (req.query.orderDirection == 'asc') {
        pagination["sort"][req.query.orderBy] = 1;
    } else {
        pagination["sort"][req.query.orderBy] = -1;
    }
  }

  const query = {status: "active"};

  if(req.query.countryId){
    query['countryId'] = req.query.countryId;
  }

  if(req.query.cityId){
    query['cityId'] = req.query.cityId;
  }

  const data = await Utility.paginate(Library, query, pagination);

  return res.success({data});
}

service.countryList = async (req, res) => {
    const library = await Utility.findDb(Library,{status: "active"});
    const countryId = [];
  
    for(const lib of library){
      countryId.push(lib.countryId);
    }
    
    const countries = await Utility.findDb(Country,{status: "active", _id: countryId});
    return res.send({data: countries});
  }
  
  service.cityList = async (req, res) => {
    const library = await Utility.findDb(Library,{status: "active", countryId: req.query.countryId});
    const cityId = [];
  
    for(const lib of library){
      cityId.push(lib.cityId);
    }
  
    const cities = await Utility.findDb(City,{status: "active", _id: cityId});
    return res.send({data: cities});
  }

export default service;