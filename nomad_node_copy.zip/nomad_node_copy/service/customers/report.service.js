import Report from '../../models/report.model.js';
import Utility from '../../library/utility.js';
import User from '../../models/user.model.js';

var service = {};

service.report = async (req, res) => {
        const customerId = req.user._id;
        const customerData = await Utility.getOneDb(User, {_id: customerId});
        const customerName = customerData.firstName +' '+ customerData.lastName;
        const { reportType, message } = req.body;

        let report = {};

        if(reportType == 'reschedule_session'){
            report = 'Reschedule session';
        } else if (reportType == 'absent_consultant'){
            report = 'Absent consultant';
        } else if (reportType == 'session_not_satisfactory') {
            report = 'Session not satisfactory';
        }

        await Report.create({
            customerId,
            reportType,
            message,
        });

        let params = {
            to: process.env.MAIL_FROM,
            subject: "Report",
            content: {customerName, report, message},
            template: "report.html"
        };
        await Utility.sendMail(params);

        return res.success({msg: 'Report send successfully!!'});
}
module.exports = service;