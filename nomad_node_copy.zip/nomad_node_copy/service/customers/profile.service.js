import User from '../../models/user.model.js';
import Utility from '../../library/utility.js';
const bcrypt = require('bcrypt');
var service = {};

service.editProfile = async (req, res) => {
  // try {
    const customerId = req.user._id;
    const customerData = await Utility.getOneDb(User, {_id: customerId});
    let country = req.body.country ? req.body.country : "";
    let firstName = req.body.firstName ? req.body.firstName : "";
    let lastName = req.body.lastName ? req.body.lastName : "";
    let preferrdName = req.body.preferrdName ? req.body.preferrdName : "";
    let pronouns = req.body.pronouns ? req.body.pronouns : "";
    let title = req.body.title ? req.body.title : "";
    let email = req.body.email ? req.body.email : "";
    let nativeLanguage = req.body.nativeLanguage ? req.body.nativeLanguage : "";
    let languages = req.body.languages ? req.body.languages: [];
    let editProfile = {
      country: country,
      firstName: firstName,
      lastName: lastName,
      preferrdName: preferrdName,
      pronouns: pronouns,
      title: title,
      email: email,
      nativeLanguage: nativeLanguage,
      languages: languages
    }
    
    let editToCustomer = {
      query: { _id: customerId },
      set: { "$set": editProfile }
    }

    await Utility.updateDb(User, editToCustomer.query, editToCustomer.set);
  
    return res.success({msg: 'Updated successfully!!'});
  // } catch (err) {
  //   return res.error({errorMsg:'Something went wrong!!'});
  // }
}

service.demographicInfo = async (req, res) => {
  try {
    const customerId = req.user._id;
    let raceOrEthenicity = req.body.raceOrEthenicity ? req.body.raceOrEthenicity : "";
    let gender = req.body.gender ? req.body.gender : "";
    let lgbtq = req.body.lgbtq ? req.body.lgbtq : "";

    let editDemographicInfo = {
        raceOrEthenicity: raceOrEthenicity,
        gender: gender,
        lgbtq: lgbtq,
      }

      let editToDemographicInfo = {
        query: { _id: customerId },
        set: { "$set": editDemographicInfo }
      }

      await Utility.updateDb(User, editToDemographicInfo.query, editToDemographicInfo.set);
    
      return res.success({msg: 'Updated successfully!!'});
    } catch (err) {
      return res.error({errorMsg:'Something went wrong!!'});
    }
}

service.currentNeed = async (req, res) => {
  try {
    const customerId = req.user._id;
    let currentNeed = req.body.currentNeed ? req.body.currentNeed : "";

    let editCurrentNeed = {
      currentNeed: currentNeed,
    }

    let editToEditCurrentNeed = {
      query: { _id: customerId },
      set: { "$set": editCurrentNeed }
    }

    await Utility.updateDb(User, editToEditCurrentNeed.query, editToEditCurrentNeed.set);
    
    return res.success({msg: 'Updated successfully!!'});
  } catch (err) {
    return res.error({errorMsg:'Something went wrong!!'});
  }
}

service.customerDetails = async (req, res) => {
  try {
    const customerId = req.user._id;
    const customerData = await Utility.getOneDb(User, {_id: customerId});
  
    if(customerData) {
      let customer = {
        firstName: customerData.firstName,
        lastName: customerData.lastName,
        preferrdName: customerData.preferrdName,
        phone: customerData.phone,
        country: customerData.country,
        pronouns: customerData.pronouns,
        email: customerData.email,
        gender: customerData.gender,
        raceOrEthenicity: customerData.raceOrEthenicity,
        currentNeed: customerData.currentNeed,
        lgbtq: customerData.lgbtq,
        title: customerData.title,
        discount_status: customerData.discount_status,
        nativeLanguage:  customerData.nativeLanguage,
        languages: customerData.languages
      }
      return res.success({data: customer});
    }
    return res.error({errorMsg: "Customer not found!!"});
  } catch (err) {
    return res.error({errorMsg:'Something went wrong!!'});
  }
}

export default service;