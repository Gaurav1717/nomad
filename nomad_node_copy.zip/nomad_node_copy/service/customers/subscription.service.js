import Subscription from '../../models/subscription.model.js';
import Utility from '../../library/utility.js';

var service = {};

service.getSubscription = async ( req, res ) => {
    const subscription = await Utility.getOneDb(Subscription, {status: {"$ne": "expired"}, customerId: req.user._id, subscription_type: "monthly"}, {"endDate": -1});
    const countSubscription = await Utility.getCount(Subscription, {status: {"$ne": "expired"}, customerId: req.user._id, subscription_type: "single"});
    
    const subscribed = await Utility.getOneDb(Subscription, {customerId: req.user._id, subscription_type: "monthly"});
    let everSubscribed = '';
    if(subscribed){
        everSubscribed = "yes";
    } else {
        everSubscribed = "no";
    }

    return res.success({subscription: subscription, countSubscription: countSubscription, everSubscribed: everSubscribed});
}

export default service;