import User from '../../models/user.model.js';
import Utility from '../../library/utility.js';

var service = {};

service.updateProfile = async (req, res) => {
    const consultantId = req.user._id;
    const logo = 'logo';

    let editProfile = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        jobTitle: req.body.jobTitle,
        backpackerOrExpat: req.body.backpackerOrExpat,
        tellUs: req.body.tellUs,
        consultantCountries: req.body.consultantCountries ? JSON.parse(req.body.consultantCountries): [],
        languages: req.body.languages ? JSON.parse(req.body.languages): [],
        linkedInLink: req.body.linkedInLink,
    }

    if (req.files && req.files.image) {
        editProfile.image = await Utility.fileUpload(req.files.image, logo);
    }

    let editToConsultant = {
        query: { _id: consultantId },
        set: { "$set": editProfile }
    }

    await Utility.updateDb(User, editToConsultant.query, editToConsultant.set);
    return res.success({msg: 'Updated successfully!!'});
}

service.consultantDetails = async (req, res) => {
    const consultant = await Utility.getOneDb(User, {_id: req.user._id}, {password: 0});
    return res.success({data: consultant});
}

export default service;