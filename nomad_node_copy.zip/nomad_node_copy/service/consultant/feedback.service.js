import User from '../../models/user.model.js';
import Session from '../../models/session.model.js';
import Feedback from '../../models/feedback.model.js';
import Country from '../../models/country.model.js';
import Utility from '../../library/utility.js';
const bcrypt = require('bcrypt');

var service = {};

service.customerFeedback = async (req, res) => {
    try {
        var sessionIds = [];
        var userObj = {};
        var userIds = [];
        var contryIds = [];
        var contryObj = {};
 
        const consultantId = req.user._id;
        const pagination = {
            page: req.query.page ? req.query.page : 1,
            limit: req.query.limit ? req.query.limit : 10,
        };
        const customerFeedback = await Utility.paginate(Feedback, {consultantId: consultantId}, pagination);

        for(const feedback of customerFeedback.docs){
            sessionIds.push(feedback.sessionId);
        }

        const sessions = await Utility.findDb(Session, {_id: {"$in": sessionIds}});

        for(const session of sessions){
            userIds.push(session.customerId);
        }

        const users = await Utility.findDb(User, {_id: {"$in": userIds}});
        
        for(const user of users){
            userObj[user._id] = {
                name:user.firstName+' '+user.lastName,
                country:user.country,
            };
            contryIds.push(user.country);
        }

        const countries = await Utility.findDb(Country, {_id: {"$in": contryIds}});

        for(const country of countries){
            contryObj[country._id] = country.name;
        }
    
        const docs = JSON.parse(JSON.stringify(customerFeedback.docs));
        for(const i in docs){
            docs[i].customerName = userObj[docs[i].customerId].name;
            docs[i].countryName = contryObj[userObj[docs[i].customerId].country];
        }
    
        customerFeedback.docs = docs;
    
        return res.success({data: customerFeedback});
    } catch (err) {
        return res.error({errorMsg:'Something went wrong!!'})
    }
}

export default service;