import User from '../../models/user.model.js';
import Session from '../../models/session.model.js';
import Utility from '../../library/utility.js';
import Subscription from '../../models/subscription.model.js';
import moment from 'moment-timezone';
const bcrypt = require('bcrypt');

var service = {};

service.sessionList = async (req, res) => {
    var userObj = {};
    var userIds = [];
    const consultantId = req.user._id;
    
    const pagination = {
        page: req.query.page ? req.query.page : 1,
        limit: req.query.limit ? req.query.limit : 10,
    };

    if(req.query.orderBy){
        pagination["sort"] = {};
        if (req.query.orderDirection == 'asc') {
            pagination["sort"][req.query.orderBy] = 1;
        } else {
            pagination["sort"][req.query.orderBy] = -1;
        }
    }

    let query = {consultantId: consultantId};
    // if(req.query.status == "cancel"){
    //     query["status"] = {"$in": ['cancelledByConsultant', 'cancelledByCustomer']};
    // }
    // else{
    //     query["status"] = req.query.status;
    // }

    if(req.query.status == "scheduled"){
        query["status"] = {"$in": ['scheduled', 'completed']};
        let today = new Date();
        today.setHours(today.getHours() - 1);
        query["dateTime"] = {"$gte": today};
    }
    else if(req.query.status == "upcomingCancelled"){
        query["status"] = {"$in": ['cancelledByConsultant', 'cancelledByCustomer']};
        query["dateTime"] = {"$gte": new Date()};
    }
    else if(req.query.status == "previous"){
        let today = new Date();
        today.setHours(today.getHours() - 1);

        query["status"] = {"$in": ['scheduled', 'completed']};
        query["dateTime"] = {"$lt": new Date()};
    }
    else if(req.query.status == "previousCancelled"){
        query["status"] = {"$in": ['cancelledByConsultant', 'cancelledByCustomer']};
        query["dateTime"] = {"$lt": new Date()};
    }

    const data = await Utility.paginate(Session, query, pagination);

    for(const row of data.docs){
        userIds.push(row.customerId);
    }

    const users = await Utility.findDb(User, {_id: {"$in": userIds}});

    for(const user of users){
        userObj[user._id] = user.firstName+" "+user.lastName;
    }

    let docs = JSON.parse(JSON.stringify(data.docs));
    for(const i in docs){
        docs[i].customerName = userObj[docs[i].customerId];
    }

    data.docs = docs;
    
    return res.success({data});
}

service.cancelSession = async (req, res) => {
    // try {
        let data = {
            "$set": {
                status: "cancelledByConsultant",
            }
        };

        const sessionQuery = { _id: req.body._id };

        const sessionData = await Utility.getOneDb(Session, {_id: sessionQuery});

        if(sessionData.subscription_type === 'single'){
            const subscription = await Utility.getOneDb(Subscription, {customerId: sessionData.customerId, status: "expired" });
            
            await Utility.updateDb(Subscription, {
                _id: subscription._id
            },{
                remainingSession: 0,
                status: "running"
            });    
        }
        
        const customerData = await Utility.getOneDb(User, {_id: sessionData.customerId});

        const timeZone = moment.tz(sessionData.dateTime,"America/Los_Angeles").format("ddd, MMM D hh:mm A")+" PDT";

        var dataToMail = {
            firstName:customerData.firstName, 
            lastName:customerData.lastName, 
            language:sessionData.language, 
            dateTime:timeZone
        };

        let params = {
            to: customerData.email,
            subject: "Cancelled Session",
            content: dataToMail,
            template: "cancelled_session.html"
        }
        await Utility.sendMail(params);

        await Utility.updateDb(Session, sessionQuery, data);
        
        return res.success({msg: 'Session cancelled successfully!!'});
    // } catch (err) {
    //     return res.error({errorMsg:'Something went wrong!!'});
    // }
}

export default service;