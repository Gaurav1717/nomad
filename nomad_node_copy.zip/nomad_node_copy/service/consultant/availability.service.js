import Availability from '../../models/availability.model.js';
import Session from '../../models/session.model.js';
import Utility from '../../library/utility.js';
const bcrypt = require('bcrypt');
//import moment from 'moment';

var service = {};

service.addAvailability = async (req, res) => {
    try {
        const consultantId = req.user._id;
        const { slotType, startTime, endTime } = req.body;
        const query = {consultantId, startTime: req.body.startTime, endTime: req.body.endTime};
        const oldSlot = await Utility.getOneDb(Availability, query);

        if (oldSlot) {
            return res.error({ "errorMsg": "Slot Already exist with this date. Please select another slot." });
        }
       
        const availabilityData = await Availability.create({
            consultantId,
            slotType,
            startTime,
            endTime
        });

        return res.success({data: availabilityData});
    } catch (err) {
        return res.error({errorMsg:'Something is wrong!!'});
    }
}

service.deleteAvailability = async (req, res) => {
    try {
        const availabilityId = req.user._id;
        if(availabilityId) {
            await Utility.deleteDb(Availability, {_id: req.body._id});
        }
        return res.success({msg: "Deleted successfully!!"});
    } catch (err) {
        return res.error({errorMsg:'Something is wrong!!'});
    }
}

service.slotAvailability = async (req, res) => {
    try {
        const consultantId = req.user._id;
        const search_start_date = req.body.startTime;
        const search_end_date = req.body.endTime;
        
        const query = {
            "consultantId": consultantId,
            "startTime": { "$gte": search_start_date, "$lte": search_end_date },
            "endTime": {"$gte": search_start_date, "$lte": search_end_date }
        };
        let slotAvailability = await Utility.findDb(Availability, query); 
        const sessionQuery = { "$and": [{ status: "scheduled" },{ "dateTime": { "$gte": search_start_date, "$lte": search_end_date } }, {"$or": [ {  consultantId: consultantId } ]}] };
        let sessions = await Utility.findDb(Session, sessionQuery); 
        return res.success({data: slotAvailability, sessions: sessions});
    } catch (err) {
    return res.error({errorMsg:'Something went wrong!!'})
    }
}

export default service;