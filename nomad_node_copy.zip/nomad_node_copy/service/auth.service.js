const User = require('../models/user.model.js');
import jwt from 'jsonwebtoken';
import Utility from '../library/utility.js';
const bcrypt = require('bcrypt');
var service = {};

service.register = async (req, res) => {
  try {
    // Get user input
    const { firstName, lastName, password, phone, country, gender, timeZone, affiliateId} = req.body;

    const email = req.body.email.toLowerCase() // sanitize: convert email to lowercase

    let query = { email: email }

    // check if user already exist
    let oldUser = await Utility.getOneDb(User, query);

    if (oldUser) {
      return res.error({ "errorMsg": "User Already Exist. Please Login." });
    }

    //Encrypt user password
    var encryptedPassword = await bcrypt.hash(password, 8);

    var token = jwt.sign({email: email}, process.env.JWT_SECRET);

    let insertUser = {
      firstName,
      lastName,
      phone,
      country,
      gender,
      timeZone,
      email: email,
      password: encryptedPassword,
      confirmationCode: token,
      userType: 'customer'
    }

    // Create user in our database
    if (affiliateId) {
      insertUser.affiliateId = affiliateId;
    }

    const user = await User.create(insertUser);

    if (user) {
      const link = process.env.BASE_URL+ "/verify-user/"+token;
      let params = {
        to: req.body.email,
        subject: user.firstName +' | '+ 'Nomad Grab - Verification Email',
        content: {firstName, link},
        template: "verification.html"
      };
      
      await Utility.sendMail(params);

      return res.success({msg: "Register successfully!!"});
    } else {
      return res.error({errorMsg: "Something is wrong, Please try again!"});
    }
  } catch (err) {
    return res.error({errorMsg: "Something is wrong!"});
  }
}

service.verify = async (req, res, next) => {
  try {
    const user = await Utility.getOneDb(User, {confirmationCode: req.body.confirmationCode});

    if(user){
      user.confirmationCode = "";
      user.emailVerified = true;
      user.save();

      let params = {
        to: user.email,
        subject: user.firstName +' | '+ 'Ike Introduction',
        content: {firstName: user.firstName},
        template: "customer_welcome.html" 
      }
      await Utility.sendMail(params);
      return res.success({});
    }
    else{
      return res.error({errorMsg: "Invalid code!!"});
    }

  } catch (err){
    return res.error({errorMsg: "Something went wrong!!"});
  }
}

service.login = async (req, res) => {
  try {

    // Get user input
    let { email, password } = req.body;
    email = email.toLowerCase();

    // Validate if user exist in our database
    const user = await User.findOne({ email });

    if (user && (await bcrypt.compare(password, user.password))) {

      if(user.emailVerified && user.status == 'active'){
        // Create token
        //const token = jwt.sign( { _id: user._id, email, userType: user.userType }, process.env.JWT_SECRET, { expiresIn: "2h"});
        const token = jwt.sign( { _id: user._id, email, userType: user.userType, firstName: user.firstName, lastName: user.lastName, country: user.country }, process.env.JWT_SECRET);

        // save user token
        let user_data = JSON.parse(JSON.stringify(user));
        user_data.token = token;
        user_data.password = "";

        // user
        return res.success(user_data);
      }
      
      return res.error({errorMsg: "Email not verified."});
    }

    return res.error({errorMsg: "Invalid Credentials"});
  } catch (err) {
    console.log(err);
  }
}

service.forgot_password = async (req, res) => {
  try {

    // Get user input
    let { email } = req.body;
    email = email.toLowerCase();

    // Validate if user exist in our database
    const user = await User.findOne({ email });

    if (user) {
      var token = jwt.sign({email: email}, process.env.JWT_SECRET);

      user.confirmationCode = token;
      user.save();
      
      const link = process.env.BASE_URL+ "/reset-password/"+token;
      let params = {
        to: email,
        subject: "Forgot Password",
        content: {firstName: user.firstName, lastName: user.lastName, link},
        template: "forgot_password.html"
      };
      
      await Utility.sendMail(params);
      
      return res.success();
    }

    return res.error({errorMsg: "This email is not registerd!!"});
  } catch (err) {
    return res.error({errorMsg:'Something went wrong!!'});
  }
}

service.reset_password = async (req, res, next) => {
  try {
    const {confirmationCode, newPassword} = req.body;
    const user = await Utility.getOneDb(User, {confirmationCode: confirmationCode});

    if(user){
      var encryptedPassword = await bcrypt.hash(newPassword, 8);

      user.confirmationCode = "";
      user.emailVerified = true;
      user.password = encryptedPassword;
      user.save();

      return res.success({});
    }
    else{
      return res.error({errorMsg: "Invalid code!!"});
    }

  } catch (err){
    return res.error({errorMsg: "Something went wrong!!"});
  }
}

service.changePassword = async (req, res) => {
  try {
    const {oldPassword, newPassword } = req.body;
    const userData = await Utility.getOneDb(User, {_id: req.user._id});

    if (userData && (await bcrypt.compare(oldPassword, userData.password))) {
      var encryptedPassword = await bcrypt.hash(newPassword, 8);
      let changePass = {
        password: encryptedPassword,
      }
      let passwordToChange = {
        query: { _id: req.user._id },
        set: { "$set": changePass }
      }
      await Utility.updateDb(User, passwordToChange.query, passwordToChange.set);
      return res.success({msg: 'Password changed successfully!!'});
    }
    return res.error({errorMsg:'Wrong password!!'});
   } catch (err) {
    return res.error({errorMsg:'Something went wrong!!'});
   }
}

export default service;