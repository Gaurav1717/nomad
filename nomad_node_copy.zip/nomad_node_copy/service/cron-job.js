import cron from 'node-cron';
import Subscription from '../models/subscription.model';
import Session from '../models/session.model';
import User from '../models/user.model';
import Payment from '../models/payment.model';
import Utility from '../library/utility';
import axios from 'axios';
import jsoncsv from 'json-csv';
const momentTZ = require('moment-timezone');
const moment = require('moment');
import fs from 'fs';
import mongoose from 'mongoose';

/** Check subscription expired */
const task1 = cron.schedule('0 */6 * * *', async () => {
    check_subscription();
});

// const task2 = cron.schedule('* */4 * * *', async () => {
//     four_hour_email_reminder();
// });

// const task3 = cron.schedule('*/15 * * * *', async () => {
//     fifteen_min_email_reminder();
// });

// const task4 = cron.schedule('* * * * 7', async () => {
//     conultant_sunday_reminder();
// });

/** Send weekly mail to subscribed user */
// const task5 = cron.schedule('0 0 * * 7', async () => {
//     send_weekly_mail_to_customer();
// });

/** Send weekly mail to subscribed user */
const task5 = cron.schedule('0 0 * * 7', async () => {
    send_weekly_mail();
});

const task6 = cron.schedule('0 0 * * 7', async () => {
    send_csv_weekly_report();
});

task1.start();
// task2.start();
// task3.start();
// task4.start();
task5.start();
task6.start();

var service = {};

const check_subscription = async() => {
    const subscriptionIds = [];

    /** Fetch all expired subscriptions */
    const expired_subscriptions = await Utility.findDb(Subscription, {status: {"$ne": "expired"}, subscription_type: "monthly", endDate: {"$lt": new Date()}});
    
    for(const expired_subscription of expired_subscriptions){
        try{
            const session_token = await Utility.paypalAccessToken();
            const url = process.env.PAYPAL_SUBSCRIPTION_URL+"/"+expired_subscription.trasactionId
            const options = {
                url: url,
                method: "GET",
                headers: {
                    'Authorization': 'Bearer '+session_token
                }
            };
            
            const paypalRes = await axios(options).catch((err, res) => {
                console.log("err, res", err, res)
            });

            if(!paypalRes || !paypalRes.data || paypalRes.data.status != 'ACTIVE'){
                subscriptionIds.push(expired_subscription._id);
            } else {
                const subscriptionUrl = process.env.PAYPAL_SUBSCRIPTION_URL+"/"+expired_subscription.trasactionId+"/"+'revise';
                if(paypalRes.data.plan_id == process.env.PAYPAL_DISCOUNT_PLAN_ID){
                    const options1 = {
                        url: subscriptionUrl,
                        method: "POST",
                        data:{
                            "plan_id": process.env.PAYPAL_PLAN_ID
                        },
                        headers: {
                            'Authorization': 'Bearer '+session_token
                        }
                    };

                    await axios(options1).catch((err, res) => {
                        console.log("err, res", err, res)
                    });
                }
                const nextBillingDate = new Date(paypalRes.data.billing_info.next_billing_time);

                if(nextBillingDate > new Date()) {
                    const paymentData = {
                        customerId: expired_subscription.customerId,
                        trasactionId: expired_subscription.trasactionId,
                        currency_code: paypalRes.data.billing_info.last_payment.amount.currency_code,
                        value: paypalRes.data.billing_info.last_payment.amount.value,
                        payload: paypalRes.data
                    }

                    const paymentSaved = await Utility.addDb(Payment, paymentData);

                    const subscriptionData = {
                        customerId: expired_subscription.customerId,
                        paymentId: paymentSaved._id,
                        trasactionId: expired_subscription.trasactionId,
                        amount: paypalRes.data.billing_info.last_payment.amount.value,
                        startDate: paypalRes.data.start_time,
                        endDate: paypalRes.data.billing_info.next_billing_time,
                        remainingSession: 0,
                        status: 'running',
                        subscription_type: 'monthly',
                        recurance: true
                    }
                    await Utility.addDb(Subscription, subscriptionData);
                    subscriptionIds.push(expired_subscription._id);
                }
            }
        }
        catch(err){
            console.log("error", err)
        }
    }

    /** Updating all upcomming subscriptions */
    if(subscriptionIds && subscriptionIds.length){
        await Utility.updateDb(Subscription, {_id: {"$in": subscriptionIds}}, {status: "expired"});
    }
    
    return true;
}

const send_csv_weekly_report = async() => {
    const beforeSixDays = new Date().setDate(new Date().getDate() - 6);
    const dateBeforeSixDays = new Date(beforeSixDays);
    const currDate = new Date();

    let end_date = new Date(currDate);
    end_date = new Date(end_date).setHours(23, 59, 59, 999);
    end_date = new Date(end_date);

    let query = {
        userType: "consultant",
    }

    const params = {
        query: query,
        startDate: new Date(dateBeforeSixDays),
        endDate: end_date
    }

    const consultants = await User.userList(params);
    
    const options = {
        fields: [
          {
            name: 'firstName',
            label: 'First name',
          },
          {
            name: 'lastName',
            label: 'Last name',
          },
          {
            name: 'totallSessionCount',
            label: "Total session",
          },
          {
            name: 'compledtedSessionCount',
            label: 'Completed session',
          },
        ],
    }

    const csvData = await jsoncsv.buffered(consultants.data, options);

    const reportParams = {
        to: process.env.ADMIN_MAIL,
        subject: "Session weekly report",
        template: "csv_weekly_reminder.html",
        attachment: {
            filename: "report.csv",
            content: csvData
        },
    };
    
    await Utility.sendMail(reportParams)
}


const four_hour_email_reminder = async() => {
    /** Fetch all session subscriptions */
    let dateTime = momentTZ(new Date())
    let currentTime = moment(dateTime).tz("America/Los_Angeles")
    dateTime = dateTime.format('MM-D-YYYY')
    let today = new Date();
    today.setHours(0,0,0,0);
    let tmrwDate = new Date().setDate(new Date().getDate() + 1);
    const today_schedule_sessions = await Utility.findDb(Session, 
        {
            status: "scheduled", 
            dateTime: {
                $gte: new Date(today), 
                $lt: new Date(tmrwDate)
            }
        });
    for(let i = 0; i < today_schedule_sessions.length; i++){
        let slotDateTime = new Date(`${today_schedule_sessions[i].slotDate} ${today_schedule_sessions[i].slotTime}`)
        slotDateTime = moment(slotDateTime)
        const hours = slotDateTime.hours() - currentTime.hours()
        console.log('hours diff',hours)
        if(
            hours <= 4 &&
            hours > 0
        ){
            const customer = await Utility.getOneDb(User, {
                _id: today_schedule_sessions[i].customerId
            });
            const emailSession = {
                customerName: customer.firstName +' '+ customer.lastName,
                date: today_schedule_sessions[i].date,
                language: today_schedule_sessions[i].language,
                zoomLink: today_schedule_sessions[i].customerZoomLink,
                zoomId: today_schedule_sessions[i].zoomId
            }
            const params = {
                to: customer.email,
                subject: "Session",
                content: emailSession,
                template: "book_session.html"
            };
            await Utility.sendMail(params);

            // consultant email
            const consultant = await Utility.getOneDb(User, {
                _id: today_schedule_sessions[i].consultantId
            });
            const consultantEmailSession = {
                name: consultant.firstName +' '+ consultant.lastName,
                zoomLink: today_schedule_sessions[i].consultantZoomLink,
            }
            const consultantParams = {
                to: consultant.email,
                subject: "There's a traveler desperate for you!!!!",
                content: consultantEmailSession,
                template: "consultant_4_hour_session_reminder.html"
            };
            // await Utility.sendMail(consultantParams);
        }
    }
    return true;
}

const fifteen_min_email_reminder = async() => {
    /** Fetch all session subscriptions */
    console.log("fifteen_min_email_reminder")
    let currentTime = moment.tz(new Date(), "America/Los_Angeles");
    let today = new Date();
    today.setHours(0,0,0,0);
    let tmrwDate = new Date().setDate(new Date().getDate() + 1);
    const today_schedule_sessions = await Utility.findDb(Session, 
        {
            status: "scheduled",
            dateTime: {
                $gte: new Date(today), 
                $lt: new Date(tmrwDate)
            }
        });
    for(let i = 0; i < today_schedule_sessions.length; i++){
        const slotTimeFormatted = today_schedule_sessions[i].slotTime;
        const ddate = new Date(`${currentTime.format('MM-DD-YYYY')} ${slotTimeFormatted}`)
        const slotDateTime = moment.tz(ddate, "MMM Do YYYY hA", "Asia/Karachi");
        let duration = moment.duration(slotDateTime.diff(currentTime));
        const minutes = duration.asMinutes();
        console.log('minutes diff',minutes)
        if(
            minutes <= 15 && 
            minutes > 0
        ){
            // customer email
            const customer = await Utility.getOneDb(User, {
                _id: today_schedule_sessions[i].customerId
            });
            const customerEmailSession = {
                customerName: customer.firstName +' '+ customer.lastName,
                date: today_schedule_sessions[i].date,
                language: today_schedule_sessions[i].language,
                zoomLink: today_schedule_sessions[i].customerZoomLink,
                zoomId: today_schedule_sessions[i].zoomId
            }
            const customerParams = {
                to: customer.email,
                subject: "Session Reminder",
                content: customerEmailSession,
                template: "session_reminder.html"
            };
            await Utility.sendMail(customerParams);
            // consultant email
            const consultant = await Utility.getOneDb(User, {
                _id: today_schedule_sessions[i].consultantId
            });
            const consultantEmailSession = {
                name: consultant.firstName +' '+ consultant.lastName,
                zoomLink: today_schedule_sessions[i].consultantZoomLink,
            }
            const consultantParams = {
                to: consultant.email,
                subject: "A traveler needs your help!!!",
                content: consultantEmailSession,
                template: "consultant_15_min_session_reminder.html"
            };
            await Utility.sendMail(consultantParams);
        }
    }
    return true;
}

const conultant_sunday_reminder = async() => {
    /** Sunday Reminding the coaches to put
        in their available time slots into the schedule */
    const query = {userType: "consultant", status: "active"}
    const consultant = await Utility.findDb(User, query);
    let consultantName;
    for(let i = 0; i < consultant.length; i++){
        consultantName = consultant[i].firstName +' '+ consultant[i].lastName;
        const consultantEmailSession = {
            consultantName: consultant[i].firstName +' '+ consultant[i].lastName,
            name: consultant[i].firstName +' '+ consultant[i].lastName
        }
        const consultantParams = {
            name: consultantName,
            to: consultant[i].email,
            subject: "Schedule Available Slot Reminder",
            content: consultantEmailSession,
            template: "consultant_sunday_reminder.html"
        };
        await Utility.sendMail(consultantParams);
    }


    const customerquery = {userType: "customer", status: "active"}
    const customer = await Utility.findDb(User, customerquery);
    let customerName;
    for(let i = 0; i < customer.length; i++){
        customerName = customer[i].firstName +' '+ customer[i].lastName;
        const customerEmailSession = {
            customerName: customer[i].firstName +' '+ customer[i].lastName,
            name: customer[i].firstName +' '+ customer[i].lastName
        }
        const customerParams = {
            name: customerName,
            to: customer[i].email,
            subject: `Are you traveling this week?  Make sure that you're prepared for the journey ahead. <a href="${process.env.BASE_URL}/booksession">Schedule an appointment today.</a>`,
            content: customerEmailSession,
            template: "customer_sunday_reminder.html"
        };
        await Utility.sendMail(customerParams);
    }
    return true;
}

const send_weekly_mail = async() => {
    let customerName;
    const subscribedUserIds = [];

    /** Fetch all active subscribed user */
    const subscribed_users = await Utility.findDb(Subscription, {status: "running", subscription_type: "monthly"}, { deleted: false});

    for(const users of subscribed_users){
        subscribedUserIds.push(users.customerId);
    }
    const userDetails = await Utility.findDb(User, {_id: subscribedUserIds, status: "active"});
    
    for(let i = 0; i < userDetails.length; i++){
        customerName = userDetails[i].firstName +' '+ userDetails[i].lastName;
        const customerEmailSession = {
            customerName: userDetails[i].firstName +' '+ userDetails[i].lastName,
            name: userDetails[i].firstName +' '+ userDetails[i].lastName
        }

        const customerParams = {
            name: customerName,
            to: userDetails[i].email,
            subject: `Upcomming Session`,
            content: customerEmailSession,
            template: "customer_sunday_reminder.html"
        };
        await Utility.sendMail(customerParams);
        
    }

    const query = {userType: "consultant", status: "active"}
    const consultant = await Utility.findDb(User, query);
    let consultantName;
    for(let i = 0; i < consultant.length; i++){
        consultantName = consultant[i].firstName +' '+ consultant[i].lastName;
        const consultantEmailSession = {
            consultantName: consultant[i].firstName +' '+ consultant[i].lastName,
            name: consultant[i].firstName +' '+ consultant[i].lastName
        }
        
        const consultantParams = {
            name: consultantName,
            to: consultant[i].email,
            subject: "Schedule Available Slot Reminder",
            content: consultantEmailSession,
            template: "consultant_sunday_reminder.html"
        };
        await Utility.sendMail(consultantParams);
    }
    
}

export default cron;
