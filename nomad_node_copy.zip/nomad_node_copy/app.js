import express from 'express';
import * as helmet from "helmet";
import bodyParser from 'body-parser';
import engine from 'ejs-locals';
import cors from 'cors';
import path from 'path';
import fileUpload from 'express-fileupload';
import connectToDb from './db/connect';
import Utility from './library/utility';
import winston from 'winston'; 
import expressWinston from 'express-winston';
import config from './library/config';
import httpServer from 'https';
import fs from 'fs';

/* Guest */
import auth from './routes/auth.router';
import master from './routes/master.router';
import guest from './routes/guest.router';
import zoom_webhook from './routes/zoom_webhook.router';
/* /Guest */

/* Admin */
import consultantUser from './routes/admin/consultant.router';
import customerUser from './routes/admin/customer.router';
import language from './routes/admin/language.router';
import session from './routes/admin/session.router';
import demoSession from './routes/admin/demoSession.router';
import report from './routes/admin/report.router';
import upload_csv from './routes/admin/upload_csv.router';
import contactUs from './routes/admin/contactUs.router';
import dashboard from './routes/admin/dashboard.router';
import subscription from './routes/admin/subscription.router';
import library from './routes/admin/library.router';
import consultantReport from './routes/admin/consultant_report.router';
import affiliateUser from './routes/admin/affiliate.router';
/* /Admin */

/* Consultant */
import consultantAvailability from './routes/consultant/availability.router';
import consultantSession from './routes/consultant/session.router';
import consultantFeedback from './routes/consultant/feedback.router';
import consultantProfile from './routes/consultant/profile.router';
/* /Consultant */

/* Customer */
import customerLanguage from './routes/customers/language.router';
import customerConsultant from './routes/customers/consultant.router';
import customerSession from './routes/customers/session.router';
import customerProfile from './routes/customers/profile.router';
import customerFeedback from './routes/customers/feedback.router';
import customerReport from './routes/customers/report.router';
import customerPayment from './routes/customers/payment.router';
import customerSubscription from './routes/customers/subscription.router';
import libraryList from './routes/customers/library.router';
/* /Customer */

process.on('unhandledRejection', async(error) => {
  console.log("error", error);
  return "Something went wrong.";
});

var app = express();

//Security
app.use(helmet.contentSecurityPolicy({
   directives: {
     "frame-ancestors": ["'self'", process.env.BASE_URL],      
     "script-src":["'self'", "'unsafe-inline'"],
     "style-src":["'self'", "'unsafe-inline'"],
   },
 }));
app.use(helmet.crossOriginEmbedderPolicy());
app.use(helmet.crossOriginOpenerPolicy());
app.use(helmet.crossOriginResourcePolicy());
app.use(helmet.dnsPrefetchControl());
app.use(helmet.expectCt());
app.use(helmet.frameguard());
app.use(helmet.hidePoweredBy());
app.use(helmet.hsts());
app.use(helmet.ieNoOpen());
app.use(helmet.noSniff());
app.use(helmet.originAgentCluster());
app.use(helmet.permittedCrossDomainPolicies());
app.use(helmet.referrerPolicy());
app.use(helmet.xssFilter());

app.use(fileUpload());

app.use(bodyParser.urlencoded({extended: true}));

// view engine setup
app.engine('ejs', engine);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(bodyParser.json());

app.use(cors({
  "origin": '*'
}))

app.use("/.well-known/acme-challenge/:filename", function(req, res){
  const file_text = fs.readFileSync("/home/ubuntu/certbot/.well-known/acme-challenge/"+req.params.filename);

  return res.send(file_text);
});

app.use(Utility.jwtAuth);

/* Guest */
app.use(auth);
app.use(master);
app.use(guest);
app.use(zoom_webhook);
/* /Guest */
// app.use(report);

/* Admin */
app.use(consultantUser);
app.use(customerUser);
app.use(language);
app.use(session);
app.use(demoSession);
app.use(report);
app.use(upload_csv);
app.use(contactUs);
app.use(dashboard);
app.use(subscription);
app.use(library);
app.use(consultantReport);
app.use(affiliateUser);
/* /Admin */

/* Consultant */
app.use(consultantAvailability);
app.use(consultantSession);
app.use(consultantFeedback);
app.use(consultantProfile);
/* /Consultant */

/* Customer */
app.use(customerLanguage);
app.use(customerConsultant);
app.use(customerSession);
app.use(customerProfile);
app.use(customerFeedback);
app.use(customerReport);
app.use(customerPayment);
app.use(customerSubscription);
app.use(libraryList);
/* /Customer */

/** Error logger */
app.use(expressWinston.errorLogger({
  transports: [
    new winston.transports.File({ filename: '/var/log/nomad_grab/error.log', level: 'error' }),
  ],
  format: winston.format.combine(
    winston.format.colorize(),
    winston.format.json()
  )
}));
/** /Error logger */

var http;
if (process.env.SEVER_PORT == "443") { 
  const options = {
    key: fs.readFileSync(process.env.SSL_KEY_FILE),
    cert: fs.readFileSync(process.env.SSL_CERT_FILE),
    ca: fs.readFileSync(process.env.SSL_CA_FILE)
  };

  http = httpServer.createServer(options, app);

  const http_80 = require('http').createServer(app);
  http_80.listen(80);
} else {
  http = require('http').createServer(app);
}

connectToDb();

require('./service/cron-job');

http.listen(process.env.SEVER_PORT);