const nodemailer = require('nodemailer'); 
require('dotenv').config()

let config = {
    transporter: {}
};

config.transporter = nodemailer.createTransport({
    host: process.env.MAIL_HOST,
    port: process.env.MAIL_PORT,
    auth: {
        user: process.env.MAIL_USER,
        pass: process.env.MAIL_PASSWORD,
    }
});

// const sgMail = require('@sendgrid/mail');

// config.transporter.sendMail = (dto) => {
//   const email_from = dto.from;
//   const api = process.env.MAIL_PASSWORD;
//   sgMail.setApiKey(api);

//   const msg = {
//     to: dto.to,
//     from: email_from,
//     subject: dto.subject,
//     text: 'NomadGrab',
//     html: dto.html,

//   };
//   sgMail
//     .send(msg)
//     .then(() => {
//       console.log('Email Sent');
//     })
//     .catch((error) => {
//       console.log(error);
//       console.log('Email Not Sent');
//     });
// };


export default config;