import jwt from 'jsonwebtoken';
import ejs from 'ejs';
import config from '../library/config.js';
// import { uuid } from 'uuidv4';
import { v4 as uuidv4 } from 'uuid';
import AWS from 'aws-sdk';
import qs from 'qs';
import axios from 'axios';
require('dotenv').config();

const utility = {};

utility.loginRequired = function (req, res, next) {
    if (req.user) {
        next();
    } else {
        return res.status(401).json({ success: false, code: 401, msg: 'Unauthorized user!' });
    }
};

utility.jwtAuth = async (req, res, next) => {

    res.success = (obj = {}) => {
        let newObj = {
            status: "success",
            statusCode: 200
        };

        let x;
        for (x in obj) {
            newObj[x] = obj[x];
        }

        res.status(200);
        return res.send(newObj);
    }

    res.error = (obj = {}) => {
        let newObj = {
            status: "error",
            statusCode: 500
        };

        let x;
        for (x in obj) {
            newObj[x] = obj[x];
        }
  
        res.status(200);
        return res.send(newObj);
    }

    var arr_allowed = [
        '/login', '/register', '/verify', '/forgot-password', '/reset-password',
        '/countries', '/states', '/cities', '/contact-us', '/book-demo-session', '/demo-session-user-information',
        '/language-list', '/provider-information', '/provider-availability',
        '/zoom/meeting_start_stop', '/zoom/participant_join', '/health',
    ];

    if (arr_allowed.indexOf(req._parsedUrl.pathname) >= 0){
        next()
    }
    else {
        if (req.headers && req.headers.authorization) {
            jwt.verify(req.headers.authorization, process.env.JWT_SECRET, function (err, decode) {
                if (err) {
                    req.user = undefined;
                    if (err.name == "TokenExpiredError") {
                        return res.status(200).json({ success: false, code: 419, msg: 'Token expires, Please login!!' });
                    } else {
                        return utility.loginRequired(req, res, next);
                    }

                } else {
                    req.user = decode;
                    return utility.loginRequired(req, res, next);
                }
            })
        } else {
            req.user = undefined;
            return utility.loginRequired(req, res, next);
        }
    }
}

utility.addDb = async (Model, data) => {
    return Model(data).save();
}

utility.insertManyDb = async (Model, data) => {
    return Model.insertMany(data);
}

utility.insertOrUpdate = async (Model, query, data) => {
    return Model.findOneAndUpdate(query, data, { upsert: true, new: true, runValidators: true });
}

utility.updateDb = async (Model, query, data) => {
    return Model.updateMany(query, data);
}

utility.deleteDb = async (Model, query = {}) => {
    return Model.remove(query);
}

utility.findDb = async (Model, query = {}, sort = null) => {
    if (sort) {
        return Model.find(query).sort(sort);
    }
    else {
        return Model.find(query);
    }
}

utility.getCount = async (Model, query = {}) => {
    return Model.count(query);
}

utility.getOneDb = async (Model, query = {}, sort = null) => {
    if (sort) {
        return Model.findOne(query).sort(sort);
    } else {
        return Model.findOne(query);
    }
}

utility.getDb = async (Model, query = null, orderby = null, limit = null, skip = null) => {
    let returnData = {};
    returnData.count = await Model.count(query);
    let pipline = [];
    if (query) {
        pipline.push({ $match: query });
    }
    if (orderby) {
        pipline.push({ $sort: orderby });
    }
    if (limit && (skip || skip == 0)) {
        skip = skip * limit;
        limit = skip + limit;
        pipline.push({ $limit: limit });
        pipline.push({ $skip: skip });
    }

    returnData.data = await Model.aggregate(pipline);
    return returnData
}

utility.paginate = async (Model, query = {}, options = {}) => {
    return Model.paginate(query, options);
}

utility.removeFile = async (fileName) => {
    var bucketInstance = new AWS.S3();
    var params = {
        Bucket: process.env.S3_Bucket,
        Key: fileName
    };
    bucketInstance.deleteObject(params, function (err, data) {
        if (data) {
            console.log("File deleted successfully");
        }
        else {
            console.log("Check if you have sufficient permissions : "+err);
        }
    });
}

utility.sendMail = async (params) => {
    params.content = params.content?params.content:[];
    params.content.subject = params.subject;
    params.content.BASE_URL = process.env.BASE_URL;

    params.content.body = await ejs.renderFile("views/email/" + params.template, params.content, {});
    let html = await ejs.renderFile("views/email/templete.ejs", params.content, {});

    var mailOptions = {
        from: process.env.MAIL_FROM_NAME + ' <' + process.env.MAIL_FROM + '>',
        to: params.to,
        subject: params.subject,
        html: html
    };

    if (params.attachment) {
        mailOptions.attachments = [params.attachment];
    }

    config.transporter.sendMail(mailOptions, function (error, info) {
        if (error) {
            console.log(error);
            
        } else {
            console.log('Email sent: ' + info.response);
            let response = {
                email: info.envelope.to,
                subject: params.subject,
                status: 'success'
            }; 
        }
        return info;
    });
}

utility.fileUpload = async (fileData, folder) => {
    let explodes = fileData.name.split(".");
    let extension = explodes.pop();
    extension = extension.toLowerCase();
    let file_name = uuidv4() + '.' + extension;
    var fileName = folder+'/'+file_name;
      
    AWS.config.update({
        accessKeyId: process.env.S3_ACCESS_KEY,
        secretAccessKey: process.env.S3_SECRET_KEY
    });

    var s3 = new AWS.S3();

    var params = {
        Bucket: process.env.S3_Bucket,
        Key: fileName, //file.name doesn't exist as a property
        Body: fileData.data,        
        ACL: 'public-read'
    };

    if(extension == 'pdf' || extension == 'PDF'){
        params.ContentType = "application/pdf";
    }
    
    await s3.upload(params, function (error, data) {
        // console.log('error', error, 'data', data);
    });
    return fileName;
}

utility.paypalAccessToken = async() => {

    var data = qs.stringify({
        'grant_type': 'client_credentials' 
    });
    
    const options = {
        url: process.env.PAYPAL_LOGIN_URL,
        method: "POST",
        auth: {
            username: process.env.PAYPAL_USERNAME,
            password: process.env.PAYPAL_PASSWORD
        },
        data: data,
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    };
    
    const paypalRes = await axios(options);
    
    return paypalRes.data.access_token;
}

utility.zoomAccessToken = async() => {

    var data = qs.stringify({
        'grant_type': 'authorization_code' 
    });
    
    const options = {
        url: "https://zoom.us/oauth/token",
        method: "POST",
        auth: {
            Client_ID: process.env.ZOOM_CLIENT_ID,
            Client_Secret: process.env.ZOOM_CLIENT_SECRET
        },
        data: data,
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    };
    
    const paypalRes = await axios(options);
    
    return paypalRes.data.access_token;
}

export default utility;