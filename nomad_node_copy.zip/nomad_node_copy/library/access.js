let access = {};

access.admin = function(req,res,next){
    let userType = req.user.userType.toLowerCase();
    if(userType == 'admin'){
        next();
    }
    else {
        res.error({errorMsg:'Invalid User!!'});
    }
}

access.consultant = function(req,res,next){
    let userType = req.user.userType.toLowerCase();
    if(userType == 'consultant'){
        next();
    }
    else{
        res.error({errorMsg:'Invalid User!!'});
    }
}

access.customer = function(req,res,next){
    let userType = req.user.userType.toLowerCase();
    if(userType == 'customer'){
        next();
    }
    else{
        res.error({errorMsg:'Invalid User!!'});
    }
}

access.loginUser = function(req,res,next){
    let userType = req.user.userType.toLowerCase();
    if(userType == 'customer' || userType == 'consultant' || userType == 'admin'){
        next();
    }
    else{
        res.error({errorMsg:'Invalid User!!'});
    }
}


export default access;
