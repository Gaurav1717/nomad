/**
 * @file(error.msg.js) All service realted to errors    
 * @author Purti Singh <purti.singh20@gmail.com>
 * @lastModifed 07-Feb-2018
 * @lastModifedBy Purti
 */


/**
* [service is a object ]
* @type {Object}
*/

const msg = {};

msg.invalidUsrnamePassword = "Invalid Username/Password";
msg.accessDenied = "Access denied";
msg.somethigWentWrong = "Somethig went wrong";
msg.passwordNotMatch = "Password & confirm password not matched";
//Exist
msg.emailExist = "Email id is already exist.";

//Required
msg.userIdRequired = "User id is required.";
msg.LinkIdRequired = "Link id is required.";
msg.knowledgeIdRequired = "Knowledge id is required.";
msg.calendarIdRequired = "Calendar id is required.";
msg.statusRequired = "Status is required.";
msg.linkBase64Required = "Image base 64 is required.";
msg.linkExtensionRequired = "Image extension is required.";
msg.titleRequired = "Title is required.";


//error
msg.statusChangeError = "Status not update.";
msg.subscriptionAddError = "Subscription not added.";
msg.userAddError = "User not added.";
msg.editUserError = "User not updated.";
msg.addCalendarError = "Calendar date not added.";
msg.editCalendarError = "Calendar date not updated.";
msg.editMessageError = "Message not added.";
msg.addHolidayError = "Holidays not added.";
msg.editPasswordError = "Password not updated.";
msg.usernameAlreadyUsed = "Username is already used";
msg.emailAlreadyUsed = "Email is already used";
msg.addNotificationMessageError = "Notification message not added.";
msg.updateNotificationMessageError = "Notification message not updated.";
msg.supportStatusMessageError = "you are not authorize";
msg.supportUpdateMessageError = "data not updated"

export default msg;
