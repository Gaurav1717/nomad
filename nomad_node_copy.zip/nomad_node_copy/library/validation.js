import { check, validationResult } from 'express-validator';

const check_validation = (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        for(const error of errors.array()){
            return res.error({errorMsg: error.msg});
        }
    }
    
    return next();
}

var validation = {};

validation.login = [
    check('email').isEmail().withMessage('Invalid email.').not().isEmpty().withMessage("Email required."),
    check('password').not().isEmpty().withMessage("Password required."),
];

validation.register = [
    check('firstName').not().isEmpty().withMessage("Firstname required."),
    check('email').isEmail().withMessage("Invalid email.").not().isEmpty().withMessage("Email required."),
    //check('address').not().isEmpty().withMessage("Address required."),
    // check('country').not().isEmpty().withMessage("Country required."),
    // check('city').not().isEmpty().withMessage("City required."),
    // check('gender').isIn(['male', 'female', 'other']).withMessage("Gender required."),
];

validation.check_email = [
    check('email').isEmail().withMessage('Invalid email.').not().isEmpty().withMessage("Email required."),
];

validation.verify = [
    check('confirmationCode').not().isEmpty().withMessage("Code required."),
];

validation.reset_password = [
    check('newPassword').not().isEmpty().withMessage("Password required."),
    check('confirmationCode').not().isEmpty().withMessage("Code required."),
]

validation.states = [
    check('countryId').not().isEmpty().withMessage("Country Id required."),
];

validation.cities = [
    check('countryId').not().isEmpty().withMessage("Country Id required."),
];

validation.contact_us = [
    check('firstName').not().isEmpty().withMessage("First Name required."),
    check('email').isEmail().withMessage('Invalid email.').not().isEmpty().withMessage("Email required."),
    check('message').not().isEmpty().withMessage("Message required."),
];

validation.book_demo_session = [
    check('firstName').not().isEmpty().withMessage("First Name required."),
    check('email').isEmail().withMessage('Invalid email.').not().isEmpty().withMessage("Email required."),
    check('company').not().isEmpty().withMessage("Company required."),
    check('description').not().isEmpty().withMessage("Description required."),
    check('country').not().isEmpty().withMessage("Country required."),
];

validation.demo_session_user_info = [
    check('email').isEmail().withMessage('Invalid email.').not().isEmpty().withMessage("Email required."),
];

validation.add_consultant = [
    check('firstName').not().isEmpty().withMessage("First Name required."),
    check('consultantCountries').not().isEmpty().withMessage("Consultant country required."),
    check('gender').isIn(['male', 'female', 'other']).withMessage("Gender required."),
    check('email').isEmail().withMessage('Invalid email.').not().isEmpty().withMessage("Email required."),
    check('password').not().isEmpty().withMessage("Password required."),
    check('languages').not().isEmpty().withMessage("Language required."),
];

validation.update_consultant = [
    check('firstName').not().isEmpty().withMessage("First Name required."),
    check('consultantCountries').not().isEmpty().withMessage("Consultant Country required."),
    check('gender').isIn(['male', 'female', 'other']).withMessage("Gender required."),
    check('languages').not().isEmpty().withMessage("Language required."),
];

validation.addLanguage = [
    check('langName').not().isEmpty().withMessage("Language required."),
];

validation.add_availability = [
    check('startTime').not().isEmpty().withMessage("Start time required."),
    check('endTime').not().isEmpty().withMessage("End time required.")
];

validation.book_session = [
    check('consultantId').not().isEmpty().withMessage("Consultant required."),
    check('language').not().isEmpty().withMessage("Language required."),
    check('dateTime').not().isEmpty().withMessage("dateTime required."),
    check('slotDateFormatted').not().isEmpty().withMessage("Slot Date Formatted required."),
    check('slotTimeFormatted').not().isEmpty().withMessage("Slot Time Formatted required."),
];

validation.edit_profile = [
    check('firstName').not().isEmpty().withMessage("First name required."),
    check('lastName').not().isEmpty().withMessage("Last name required."),
    check('title').not().isEmpty().withMessage("Title required."),
    check('email').not().isEmpty().withMessage("Email required."),
    check('country').not().isEmpty().withMessage("Country required."),
];

validation.current_need = [
    check('currentNeed').not().isEmpty().withMessage("Current Need required."),
];

validation.slot_availability = [
    check('startTime').not().isEmpty().withMessage("Start time required."),
    check('endTime').not().isEmpty().withMessage("End time required.")
];

validation.customer_feedback = [
    check('tags').not().isEmpty().withMessage("Tag required."),
    check('progress').not().isEmpty().withMessage("Progress required."),
    check('ratings').not().isEmpty().withMessage("Ratings required."),
    check('about_situation').not().isEmpty().withMessage("About situation required."),
    check('address_situation').not().isEmpty().withMessage("Address situation required."),
    check('skill_strategy').not().isEmpty().withMessage("Skill strategy required."),
];

validation.report = [
    check('reportType').not().isEmpty().withMessage("Report required."),
    check('message').not().isEmpty().withMessage("Message required."),
];

validation.change_password = [
    check('oldPassword').not().isEmpty().withMessage("Old password required."),
    check('newPassword').not().isEmpty().withMessage("New password required."),
];

validation.update_profile = [
    check('firstName').not().isEmpty().withMessage("First name required."),
    //check('lastName').not().isEmpty().withMessage("Last name required."),
    check('jobTitle').not().isEmpty().withMessage("Job title required."),
    check('backpackerOrExpat').not().isEmpty().withMessage("Backpacker or Expat required."),
    check('tellUs').not().isEmpty().withMessage("Tell us about yourself required."),
    check('consultantCountries').not().isEmpty().withMessage("Country required."),
    check('languages').not().isEmpty().withMessage("Language required."),
    check('linkedInLink').not().isEmpty().withMessage("linked in link required."),
];

validation.verify_payment = [
    check('trasactionId').not().isEmpty().withMessage("Trasaction Id required."),
    check('subscription_type').not().isEmpty().isIn(['single', 'monthly']).withMessage("subscription_type required."),
];

validation.addLibrary = [
    check('countryId').not().isEmpty().withMessage("Country Id required."),
    check('cityId').not().isEmpty().withMessage("City Id required."),
    check('whatsapp_link').not().isEmpty().withMessage("WhatsApp link required."),
    check('group_name').not().isEmpty().withMessage("Group name required.")
];

validation.add_affiliate = [
    check('firstName').not().isEmpty().withMessage("First name required."),
    check('lastName').not().isEmpty().withMessage("Last name required."),
    check('email').not().isEmpty().withMessage("Email required."),
];

validation.update_affiliate = [
    check('firstName').not().isEmpty().withMessage("First name required."),
    check('lastName').not().isEmpty().withMessage("Last name required.")
];

export {
    validation,
    check_validation
};