import express from "express";
import guestService from '../service/guest.service.js';
import {validation, check_validation} from '../library/validation.js';

const router = express.Router();

router.post('/contact-us',validation.contact_us, check_validation, guestService.addContactUs);
router.post('/book-demo-session', validation.book_demo_session, check_validation, guestService.requestDemo);
router.post('/demo-session-user-information', validation.demo_session_user_info, check_validation, guestService.demoSessionUserInfo);
router.get('/language-list', guestService.languageList);
router.get('/health', guestService.health);

export default router;