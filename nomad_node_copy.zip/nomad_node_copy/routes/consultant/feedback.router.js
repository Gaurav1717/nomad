import express from "express";
import feedbackService from '../../service/consultant/feedback.service.js';
import {validation, check_validation} from '../../library/validation.js';
import access from "../../library/access.js";

const router = express.Router();

router.get('/consultant/customer-feedback', access.consultant, feedbackService.customerFeedback);
export default router;