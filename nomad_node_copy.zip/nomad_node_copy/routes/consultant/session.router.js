import express from "express";
import sessionService from '../../service/consultant/session.service.js';
import {validation, check_validation} from '../../library/validation.js';
import access from "../../library/access.js";

const router = express.Router();

router.post('/consultant/cancel-session', access.consultant, sessionService.cancelSession);
router.get('/consultant/session-list', access.consultant, sessionService.sessionList);
export default router;