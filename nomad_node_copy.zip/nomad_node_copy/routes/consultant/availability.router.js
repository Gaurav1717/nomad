import express from "express";
import availabilityService from '../../service/consultant/availability.service.js';
import {validation, check_validation} from '../../library/validation.js';
import access from "../../library/access.js";

const router = express.Router();

router.post('/consultant/add-availability', access.consultant, validation.add_availability, check_validation, availabilityService.addAvailability);
router.post('/consultant/delete-availability', access.consultant, availabilityService.deleteAvailability);
router.post('/consultant/slot-availability', access.consultant, validation.slot_availability, check_validation, availabilityService.slotAvailability);
export default router;