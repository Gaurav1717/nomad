import express from "express";
import profileService from '../../service/consultant/profile.service.js';
import {validation, check_validation} from '../../library/validation.js';
import access from "../../library/access.js";

const router = express.Router();

router.post('/consultant/update-profile', access.consultant, validation.update_profile, check_validation, profileService.updateProfile);
router.get('/consultant/consultant-details', access.consultant, profileService.consultantDetails);

export default router;