import express from "express";
import access from "../../library/access.js";
import service from "../../service/admin/demoSession.service.js";

const router = express.Router();

router.post('/admin/change-demo-session-status', access.admin, service.changeDemoSessionStatus);
router.get('/admin/demo-session-list', access.admin, service.demoSessionList);
router.post('/admin/schedule-demo-session', access.admin, service.scheduleDemoSession);

module.exports = router;