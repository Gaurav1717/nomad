import express from "express";
import access from "../../library/access.js";
import consultantReportService from "../../service/admin/consultant_report.service.js";

const router = express.Router();

router.get('/admin/consultant-report', access.admin, consultantReportService.consultantReport);

module.exports = router;