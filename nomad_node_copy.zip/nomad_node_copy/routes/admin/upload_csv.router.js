var express = require("express");
import uploadCsvService from "../../service/admin/upload_csv.service.js";
import access from "../../library/access.js";
var router = express.Router();

router.post('/admin/upload-country-state-city', access.admin, uploadCsvService.upload_country_state_city);

module.exports = router;