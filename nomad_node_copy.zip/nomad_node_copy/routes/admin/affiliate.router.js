var express = require("express");
import affiliateService from "../../service/admin/affiliate.service.js";
import access from "../../library/access.js";
import {validation, check_validation} from '../../library/validation.js';
var router = express.Router();

router.post('/admin/add-affiliate', access.admin, validation.add_affiliate, check_validation, affiliateService.addAffiliate);
router.post('/admin/update-affiliate', access.admin, validation.update_affiliate, check_validation, affiliateService.updateAffiliate);
router.get('/admin/affiliate-list', access.admin, affiliateService.affiliateList);

module.exports = router;