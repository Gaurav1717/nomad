import express from "express";
import access from "../../library/access.js";
import {validation, check_validation} from '../../library/validation.js';
import language from "../../service/admin/language.service.js";

const router = express.Router();

router.post('/admin/add-language', access.admin, validation.addLanguage, check_validation, language.add);
router.post('/admin/update-language', access.admin, validation.addLanguage, check_validation, language.update);
router.post('/admin/change-status-language', access.admin, language.changeStatus);
router.post('/admin/language-list', language.list);

module.exports = router;