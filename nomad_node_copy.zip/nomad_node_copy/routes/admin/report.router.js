import express from "express";
import access from "../../library/access.js";
import reportService from "../../service/admin/report.service.js";

const router = express.Router();

router.get('/admin/report-list', access.admin, reportService.reportList);

module.exports = router;