import express from "express";
import access from "../../library/access.js";
import sessionService from "../../service/admin/session.service.js";

const router = express.Router();

router.post('/admin/session-feedback', access.admin, sessionService.sessionFeedbacK);
router.get('/admin/session-list', access.admin, sessionService.sessionList);

module.exports = router;