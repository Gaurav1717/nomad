var express = require("express");
import customerService from "../../service/admin/customer.service.js";
import access from "../../library/access.js";
var router = express.Router();

router.get('/admin/customer-list', access.admin, customerService.customerList);
router.get('/admin/all-customers', access.admin, customerService.allCustomers);
router.post('/admin/customers-delete', access.admin, customerService.customersDelete);

module.exports = router;