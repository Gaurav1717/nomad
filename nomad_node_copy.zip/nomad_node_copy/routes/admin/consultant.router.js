var express = require("express");
import consultantService from "../../service/admin/consultant.service.js";
import access from "../../library/access.js";
import {validation, check_validation} from '../../library/validation.js';
var router = express.Router();

router.post('/admin/add-consultant', access.admin, validation.add_consultant, check_validation, consultantService.addConsultant);
router.post('/admin/update-consultant', access.admin, validation.update_consultant, check_validation, consultantService.updateConsultant);
router.post('/admin/consultant-availability', access.admin, consultantService.consultantAvailability);
router.post('/admin/change-consultant-status', access.admin, consultantService.changeStatus);
router.get('/admin/consultant-list', access.admin, consultantService.consultantList);
router.get('/admin/all-consultants', access.admin, consultantService.allConsultants);
router.get('/admin/detail-consultant', access.admin, consultantService.detailConsulant);
router.delete('/admin/delete-consultant', access.admin, consultantService.deleteConsultant);
router.post('/admin/resent-email-consultant', access.admin, consultantService.resentEmailConsultant);

module.exports = router;