var express = require("express");
import libraryService from "../../service/admin/library.service";
import access from "../../library/access";
import {validation, check_validation} from '../../library/validation';

var router = express.Router();

router.post('/admin/add-library', access.admin, validation.addLibrary, check_validation, libraryService.addLibrary);
router.post('/admin/change-library-status', access.admin, libraryService.changeStatus);
router.get('/admin/list-library', access.admin, libraryService.listLibrary);

module.exports = router;