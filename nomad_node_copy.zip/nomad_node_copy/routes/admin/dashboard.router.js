import express from "express";
import access from "../../library/access.js";
import dashboardService from "../../service/admin/dashboard.service.js";

const router = express.Router();

router.get('/admin/dashboard', access.admin, dashboardService.dashboard);

module.exports = router;