import express from "express";
import access from "../../library/access.js";
import contactUsService from "../../service/admin/contactUs.service.js";

const router = express.Router();

router.get('/admin/contact-us-list', access.admin, contactUsService.contactUsList);

module.exports = router;