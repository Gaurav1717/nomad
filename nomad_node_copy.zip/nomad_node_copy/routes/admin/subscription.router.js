import express from "express";
import access from "../../library/access.js";
import service from "../../service/admin/subscription.service.js";

const router = express.Router();

router.get('/admin/subscription-list', access.admin, service.list);

module.exports = router;