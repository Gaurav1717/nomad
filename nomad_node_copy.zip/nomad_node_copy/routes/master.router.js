import express from 'express';
import masterService from '../service/master.service.js';
import {validation, check_validation} from '../library/validation.js';

const router = express.Router();

router.get('/countries', masterService.countries);
router.get('/states', validation.states, check_validation, masterService.states);
router.get('/cities', validation.cities, check_validation, masterService.cities);

module.exports = router;