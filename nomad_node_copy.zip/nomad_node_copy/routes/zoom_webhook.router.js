import express from 'express';
import service from '../service/zoom_webhook.service.js';

const router = express.Router();

router.post('/zoom/meeting_start_stop', service.start_stop);
router.post('/zoom/participant_join', service.participant_join);

module.exports = router;