import express from "express";
import feedbackService from '../../service/customers/feedback.service.js';
import {validation, check_validation} from '../../library/validation.js';
import access from "../../library/access.js";
const router = express.Router();

router.post('/customer/session-feedback', access.customer, validation.customer_feedback, check_validation, feedbackService.sessionFeedback);

export default router;