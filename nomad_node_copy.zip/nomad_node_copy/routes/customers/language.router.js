import express from "express";
import languageService from '../../service/customers/language.service.js';
import access from "../../library/access.js";
const router = express.Router();

router.get('/customer/language-list', access.customer, languageService.languageList);

export default router;