import express from "express";
import sessionService from '../../service/customers/session.service.js';
import {validation, check_validation} from '../../library/validation.js';
import access from "../../library/access.js";
const router = express.Router();

router.post('/customer/session', access.customer, validation.book_session, check_validation, sessionService.session);
router.post('/customer/cancel-session', access.customer, sessionService.cancelSession);
router.get('/customer/session-list', access.customer, sessionService.sessionList);
router.get('/customer/completed-session-list', access.customer, sessionService.completedSessionList);
router.get('/customer/session_details', access.customer, sessionService.sessionDetails);

export default router;