import express from "express";
import libraryService from '../../service/customers/library.service';
import access from "../../library/access";
const router = express.Router();

router.get('/customer/library-list', access.customer, libraryService.libraryList);
router.get('/customer/library-country-list', access.customer, libraryService.countryList);
router.get('/customer/library-city-list', access.customer, libraryService.cityList);

export default router;