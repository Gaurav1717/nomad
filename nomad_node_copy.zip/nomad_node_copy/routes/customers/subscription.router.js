import express from "express";
import service from '../../service/customers/subscription.service.js';
import access from "../../library/access.js";

const router = express.Router();

router.get('/customer/subscription', access.customer, service.getSubscription);

export default router;