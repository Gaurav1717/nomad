import express from "express";
import reportService from '../../service/customers/report.service.js';
import {validation, check_validation} from '../../library/validation.js';
import access from "../../library/access.js";

const router = express.Router();

router.post('/customer/report', access.customer, validation.report, check_validation, reportService.report);
export default router;