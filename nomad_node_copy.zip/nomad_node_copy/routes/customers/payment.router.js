import express from "express";
import service from '../../service/customers/payment.service.js';
import {validation, check_validation} from '../../library/validation.js';
import access from "../../library/access.js";

const router = express.Router();

router.post('/customer/verify-payment', validation.verify_payment, check_validation, access.customer, service.verifyPayment);
router.post('/customer/cancel-payment', access.customer, service.cancelPayment);
router.post('/customer/discount-payment', access.customer, service.discountPayment);

export default router;