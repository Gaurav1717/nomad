import express from "express";
import consultantService from '../../service/customers/consultant.service.js';
import access from "../../library/access.js";

const router = express.Router();

router.get('/customer/consultant-list',  access.customer, consultantService.consultantList);
router.post('/customer/consultant-availability',  access.customer, consultantService.consultantAvailability);

export default router;