import express from "express";
import profileService from '../../service/customers/profile.service.js';
import {validation, check_validation} from '../../library/validation.js';
import access from "../../library/access.js";
const router = express.Router();

router.post('/customer/edit-profile', access.customer, validation.edit_profile, check_validation, profileService.editProfile);
router.post('/customer/demographic-info', access.customer, profileService.demographicInfo);
router.post('/customer/current-need', access.customer, validation.current_need, check_validation, profileService.currentNeed); 
router.get('/customer/customer-details', access.customer, profileService.customerDetails); 

export default router;