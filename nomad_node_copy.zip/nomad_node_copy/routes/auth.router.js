import express from 'express';
import authService from '../service/auth.service.js';
import access from "../library/access.js";
import {validation, check_validation} from '../library/validation.js';

const router = express.Router();

router.post('/register', validation.register, check_validation, authService.register);
router.post('/login', validation.login, check_validation, authService.login);
router.post('/verify', validation.verify, check_validation, authService.verify);
router.post('/forgot-password', validation.check_email, check_validation, authService.forgot_password);
router.post('/reset-password', validation.reset_password, check_validation, authService.reset_password);
router.post('/change-password', access.loginUser, validation.change_password, check_validation, authService.changePassword);

module.exports = router;