import mongoose from 'mongoose';
import mongoosePaginate from 'mongoose-paginate';
import mongoose_delete from 'mongoose-delete';

const schema = mongoose.Schema({
        langName : {type:String},
        status : {type:String, enum:['inactive', 'active'], default:"active"},
        deleted : {type:Boolean,default:false},
    },
    {
        timestamps: true,
        collection : 'language'
});

schema.plugin(mongoosePaginate);
schema.plugin(mongoose_delete, {deletedAt : true, overrideMethods: true });

module.exports = mongoose.model('language',schema);