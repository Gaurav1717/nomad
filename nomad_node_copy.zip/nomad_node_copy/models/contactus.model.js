import mongoose from 'mongoose';
import mongoosePaginate from 'mongoose-paginate';
import mongoose_delete from 'mongoose-delete';

const schema = mongoose.Schema({
    firstName: {type:String},
    lastName:{type: String },
    email: {type: String},
    message: {type:String},
    deleted : {type:Boolean,default:false},
},
{
    timestamps: true,
    collection : 'contact_us'
});

schema.plugin(mongoosePaginate);
schema.plugin(mongoose_delete, {deletedAt : true, overrideMethods: true });

module.exports = mongoose.model('contact_us',schema);