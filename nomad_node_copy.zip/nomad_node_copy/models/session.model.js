import mongoose, { Query } from 'mongoose';
import mongoosePaginate from 'mongoose-paginate';
import mongoose_delete from 'mongoose-delete';

const schema = mongoose.Schema({
    customerId: {type:mongoose.Schema.ObjectId},
    consultantId: {type:mongoose.Schema.ObjectId},
    language: { type: String },
    dateTime: { type: Date },
    slotDate: { type: String },
    slotTime: { type: String },
    zoomId: { type: String },
    customerZoomLink: { type: String },
    consultantZoomLink: { type: String },
    meetingStartTime: { type: Date },
    meetingEndTime: { type: Date },
    consultantJoinTime: { type: Date },
    customerJoinTime: { type: Date },
    status : { type:String, enum: ['scheduled', 'completed', 'cancelledByConsultant', 'cancelledByCustomer'], default:'scheduled' },
    is_reviewed: {type: Boolean, default: false}, 
    subscription_type: {type:String, enum: ['single', 'monthly'], default:null}, 
},
{
    timestamps: true,
    collection: 'session'
});

schema.plugin(mongoosePaginate);
schema.plugin(mongoose_delete, {deletedAt : true, overrideMethods: true });

module.exports = mongoose.model('session', schema);