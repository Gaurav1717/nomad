import mongoose from 'mongoose';
import mongoosePaginate from 'mongoose-paginate';
import mongoose_delete from 'mongoose-delete';

const schema = mongoose.Schema({
    customerId: {type: mongoose.Schema.ObjectId},
    paymentId: {type: mongoose.Schema.ObjectId},
    trasactionId: {type: String},
    amount: {type: String},
    startDate:{type: Date},
    endDate:{type: Date},
    remainingSession:{type: Number},
    status : {type: String, default: "running", enum: ['expired','running','upcomming']},
    subscription_type: {type:String, enum: ['single', 'monthly'], default:'monthly'},
    recurance: {type: Boolean, default: false},
},
{
    timestamps: true,
    collection : 'subscription'
});

schema.plugin(mongoosePaginate);
schema.plugin(mongoose_delete, {deletedAt : true, overrideMethods: true });

module.exports = mongoose.model('subscription', schema);