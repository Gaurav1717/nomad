import mongoose from 'mongoose';
import mongoosePaginate from 'mongoose-paginate';
import mongoose_delete from 'mongoose-delete';

const schema = mongoose.Schema({
    customerId: {type:mongoose.Schema.ObjectId},
    reportType: { type: String, enum: ['reschedule_session', 'absent_consultant', 'session_not_satisfactory',''] },
    message: {type:String},
},
{
    timestamps: true,
    collection : 'report'
});

schema.plugin(mongoosePaginate);
schema.plugin(mongoose_delete, {deletedAt : true, overrideMethods: true });

module.exports = mongoose.model('report', schema);