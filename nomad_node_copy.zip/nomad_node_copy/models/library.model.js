import mongoose from 'mongoose';
import mongoosePaginate from 'mongoose-paginate';
import mongoose_delete from 'mongoose-delete';

const schema = mongoose.Schema({
    "countryId": {type: mongoose.Schema.ObjectId},
    "cityId": {type: mongoose.Schema.ObjectId},
    "whatsapp_link": {type: String},
    "group_name": {type: String},
    "status": {type: String, enum: ['active', 'inactive'], default: 'active'},
    "activity_level": {type: String, enum: ['High', 'Medium', 'Dead'], default: 'High'},
    "category": {type: String}
},
{
    timestamps: true,
    collection : 'library'
});

schema.plugin(mongoosePaginate);
schema.plugin(mongoose_delete, {deletedAt : true, overrideMethods: true });

module.exports = mongoose.model('library', schema);
