import mongoose from 'mongoose';
import mongoose_delete from 'mongoose-delete';

const schema = mongoose.Schema({
    "countryId": {type: mongoose.Schema.ObjectId},
    "stateId": {type: mongoose.Schema.ObjectId},
    "name": {type: String},
    "status": {type: String, enum: ['active', 'inactive'], default: 'active'}
},
{
    timestamps: true,
    collection : 'city'
});

schema.plugin(mongoose_delete, {deletedAt : true, overrideMethods: true });

module.exports = mongoose.model('city', schema);