import mongoose, { Query } from 'mongoose';
import mongoosePaginate from 'mongoose-paginate';
import mongoose_delete from 'mongoose-delete';

const schema = mongoose.Schema({
    consultantId: {type:mongoose.Schema.ObjectId},
    status: { type: String, enum: ['inactive', 'active'], default: 'active' },
    slotType: { type: String, enum: ['morning', 'afternoon', 'evening'], default: "morning" },
    startTime: { type: Date, default: new Date() },
    endTime: { type: Date, default: new Date() },
},
{
    timestamps: true,
    collection: 'availability'
});
schema.plugin(mongoosePaginate);

schema.plugin(mongoose_delete, {deletedAt : true, overrideMethods: true });

module.exports = mongoose.model('availability', schema);




// Customer side logic to get available slots of the date.

// search_start_date = "2022-10-12 00:00:00AM" //Capture from frontend

// search_end_date = "2022-10-12 23:59:59PM" //capture from frontend

// start_date = new Date(search_start_date);

// end_date = new Date(search_end_date);

// Query({
//     "startTime": { "$gte": start_date, "$lte": end_date },
//     "endTime": {"$gte": start_date, "$lte": end_date }
// })