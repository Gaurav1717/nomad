import mongoose from 'mongoose';
import mongoosePaginate from 'mongoose-paginate';
import mongoose_delete from 'mongoose-delete';

const schema = mongoose.Schema({
    customerId: {type: mongoose.Schema.ObjectId},
    trasactionId: {type: String},
    currency_code: {type: String},
    value: {type: Number},
    payload: {type: Object}
},
{
    timestamps: true,
    collection : 'payment'
});

schema.plugin(mongoosePaginate);
schema.plugin(mongoose_delete, {deletedAt : true, overrideMethods: true });

module.exports = mongoose.model('payment', schema);
