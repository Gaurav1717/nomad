import mongoose from 'mongoose';
import mongoose_delete from 'mongoose-delete';

const schema = mongoose.Schema({
    "sortname": {type: String},
    "name": {type: String},
    "phone_code": {type: String},
    "status": {type: String, enum: ['active', 'inactive'], default: 'active'}
},
{
    timestamps: true,
    collection : 'country'
});

schema.plugin(mongoose_delete, {deletedAt : true, overrideMethods: true });

module.exports = mongoose.model('country', schema);