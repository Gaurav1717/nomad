import mongoose from 'mongoose';
import mongoosePaginate from 'mongoose-paginate';
import mongoose_delete from 'mongoose-delete';

const schema = mongoose.Schema({
    zoomUserId: {type:String},
    affiliateId: {type:mongoose.Schema.ObjectId},
    firstName: {type:String},
    lastName: {type:String},
    preferrdName: {type:String},
    pronouns: {type:String},
    title: {type:String},
    raceOrEthenicity: {type:String,enum:['americanNative','asian', 'black', 'latino', 'pacific', 'white', '']},
    gender: {type:String,enum:['male','female','other', '']},
    lgbtq: {type:String, enum: ["yes", "no", "i'd_prefer_not_not_say", "not_specify", '']}, 
    currentNeed: {type:String,enum:['career_planning_and_growth','role_and_career_success','coping_with_career_obstackles', '']},
    email: {type:String, required: true, unique:true},
    password: {type: String },
    phone: {type:String},
    country: {type:mongoose.Schema.ObjectId},
    city: {type:mongoose.Schema.ObjectId},
    image:{type:String},
    userType: {type:String,enum:['admin','customer','consultant', 'affiliate', '']},
    emailVerified: {type: Boolean, default: false},
    nativeLanguage:{type:String},
    languages: [],
    status: {
        type: String, 
        enum: ['inactive', 'active'],
        default: 'active'
    },
    timeZone: { type:String },
    confirmationCode: { type: String, unique: true },
    jobTitle: { type:String },
    backpackerOrExpat: { type:String, enum: ['long_term', 'travel_place_to_place'] },
    tellUs: { type:String },
    linkedInLink: { type:String },
    consultantCountries: [],
    discount_status: {type: Boolean, default: false},
    firstSubscriptionType:  {type: String},
    firstSubscriptionDate:  {type: Date}
},
{
    timestamps: true,
    collection : 'user'
});

schema.plugin(mongoosePaginate);

let userModel = mongoose.model('user', schema);

userModel.userList = async (params) => {
    let returnData = {};

    returnData.count = await userModel.count(params.query);
    let pipline = [];
    if (params.query) {
        pipline.push({ $match: params.query });
    }

    let userLookup = {
        from: "session",
        let: {
            consultantId: "$_id",
            startDate: params.startDate,
            endDate:   params.endDate    
        },
        pipeline: [
            {
                $match: {
                    $expr: {
                        $and: [
                            { $eq: ["$consultantId", "$$consultantId"] },
                            { $gte: ["$dateTime", "$$startDate"] },
                            { $lte: ["$dateTime", "$$endDate"] }
                          ]
                    }
                },

            },
        
        ],
        as: "sessionDetail",
    }
    pipline.push({ $lookup: userLookup });


    let sessionCompletedLookup = {
        from: "session",
        let: {
            consultantId: "$_id",
            startDate: params.startDate,
            endDate:   params.endDate
        },
        pipeline: [
            {
                $match: {
                    $expr: {
                        $and:[
                            {$eq: ["$consultantId", "$$consultantId"]},
                            {$eq: ["$status","completed"]},
                            { $gte: ["$dateTime", "$$startDate"] },
                            { $lte: ["$dateTime", "$$endDate"] }
                        ]
                    }
                },

            },
        ],
        as: "completedCount",
    };

    pipline.push({ $lookup: sessionCompletedLookup });

    let project = {
        // _id: "$_id",
        firstName: "$firstName",
        lastName: "$lastName",
        email: "$email",
        // sessionDetails: "$sessionDetail",
        totallSessionCount: {$size:"$sessionDetail"},
        compledtedSessionCount:{$size:"$completedCount"},
    }

    pipline.push({ $project: project });
    
    if(params.pagination){
        let skip =params.pagination.page * params.pagination.limit;
        let limit = skip + params.pagination.limit;
        pipline.push({ $limit: limit });
        pipline.push({ $skip: skip });
    }

    returnData.data = await userModel.aggregate(pipline);

    return returnData;
}

userModel.affiliateList = async (params) => {
    let returnData = {};
    returnData.count = await userModel.count(params.query);
    let pipline = [];
    if (params.query) {
        pipline.push({ $match: params.query });
    }

    let affiliateLookup = {
        from: "user",
        let: {
            affiliateId: "$_id",
        },
        pipeline: [
            {
                $match: {
                    $expr: {
                        $and: [
                            { $eq: ["$affiliateId", "$$affiliateId"] },
                            { $eq: ["$firstSubscriptionType", "monthly"] },
                          ]
                    }
                },

            },
        
        ],
        as: "monthlyAffiliateUser",
    }
    pipline.push({ $lookup: affiliateLookup });
    
    let singleTokenLookup = {
        from: "user",
        let: {
            affiliateId: "$_id",
        },
        pipeline: [
            {
                $match: {
                    $expr: {
                        $and:[
                            {$eq: ["$affiliateId", "$$affiliateId"]},
                            { $eq: ["$firstSubscriptionType", "single"] },
                        ]
                    }
                },

            },
        ],
        as: "singleAffiliateUser",
    };

    pipline.push({ $lookup: singleTokenLookup });

    let project = {
        firstName: "$firstName",
        lastName: "$lastName",
        email: "$email",
        phone: "$phone",
        monthlySubscriptionCount: {$size:"$monthlyAffiliateUser"},
        singleSubscriptionCount: {$size:"$singleAffiliateUser"},
    }

    pipline.push({ $project: project });
    
    if(params.pagination){
        let skip =params.pagination.page * params.pagination.limit;
        let limit = skip + params.pagination.limit;
        pipline.push({ $limit: limit });
        pipline.push({ $skip: skip });
    }

    returnData.data = await userModel.aggregate(pipline);

    return returnData;
}

schema.plugin(mongoose_delete, {deletedAt : true, overrideMethods: true });

module.exports = mongoose.model('user', schema);