import mongoose, { Query } from 'mongoose';
import mongoosePaginate from 'mongoose-paginate';
import mongoose_delete from 'mongoose-delete';

const schema = mongoose.Schema({
    customerId: {type:mongoose.Schema.ObjectId},
    consultantId: {type:mongoose.Schema.ObjectId},
    sessionId: {type:mongoose.Schema.ObjectId},
    tags: [],
    progress: { type: String },
    ratings: { type: Number },
    about_situation: { type: String },
    address_situation: { type: String },
    skill_strategy: { type: String },
    checkbox: { type: Boolean, default: false },
    status : { type:String, enum: ['active', 'inactive'], default:'active' },
},
{
    timestamps: true,
    collection: 'feedback'
});

schema.plugin(mongoosePaginate);
schema.plugin(mongoose_delete, {deletedAt : true, overrideMethods: true });

module.exports = mongoose.model('feedback', schema);