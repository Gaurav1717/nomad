import mongoose from 'mongoose';
import mongoosePaginate from 'mongoose-paginate';
import mongoose_delete from 'mongoose-delete';

const schema = mongoose.Schema({
    consultantId: {type:mongoose.Schema.ObjectId},
    firstName: {type:String, required: true},
    lastName: {type:String},
    email: {type:String, required: true, unique:true},
    company: {type:String, required: true},
    description: {type:String, required: true},
    dateTime: { type: Date },
    zoomId: { type: String },
    customerZoomLink: { type: String },
    consultantZoomLink: { type: String },
    meetingStartTime: { type: Date },
    meetingEndTime: { type: Date },
    consultantJoinTime: { type: Date },
    customerJoinTime: { type: Date },
    //agreement : {type:Boolean,default:false},
    status: { type: String, enum: ['booked', 'scheduled', 'completed', 'cancelled'], default: 'booked' },
    country: {type:mongoose.Schema.ObjectId, default: null},
},
{
    timestamps: true,
    collection : 'bookSession'
});
schema.plugin(mongoosePaginate);

schema.plugin(mongoose_delete, {deletedAt : true, overrideMethods: true });

module.exports = mongoose.model('bookSession',schema);