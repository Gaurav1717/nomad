const mongoose = require("mongoose");
require('dotenv').config()

/**
 * [@Promise : native promises add to mongoose promise variable]
 * @type {[object]}
 */
mongoose.Promise = global.Promise;

/**
 * @description [Connect with mongodb with host and port]
 * @return {[object]}
 */
const connectToDb = async () => {
    let connectionString = process.env.DB_CONNECTION;
    try {
        mongoose.connect(connectionString, { useNewUrlParser: true,useUnifiedTopology: true, autoIndex: false });
        console.log('Mongodb connected');
    }
    catch (err) {
        console.log(err);
        console.log('Could not connect to MongoDB');
    }
}
module.exports = connectToDb;